﻿using ZstdSharp;

public class ZstdCompressionHandler
{
    // A ZSTD Magic Number (Little Endian): 0xFD2FB528 -> 28 B5 2F FD
    private static readonly byte[] ZstdMagic = { 0x28, 0xB5, 0x2F, 0xFD };

    public bool CanHandle(byte[] data)
    {
        if (data.Length < 4) return false;
        // Ellenőrizzük az első 4 bájtot
        return data[0] == ZstdMagic[0] && data[1] == ZstdMagic[1] &&
               data[2] == ZstdMagic[2] && data[3] == ZstdMagic[3];
    }

    public byte[] Decompress(byte[] data)
    {
        using var decompressor = new Decompressor();
        return decompressor.Unwrap(data).ToArray();
    }
}
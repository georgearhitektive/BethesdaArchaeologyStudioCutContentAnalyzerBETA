﻿using System;
using System.Collections.Generic;
using System.Linq;
using BethesdaArchaeologyStudio.Core.Enums;

namespace BethesdaArchaeologyStudio.Parser.Compression
{
    public class CompressionManager
    {
        private readonly ZstdCompressionHandler _zstdHandler;
        private readonly ZLibCompressionHandler _zlibHandler;

        public CompressionManager()
        {
            _zstdHandler = new ZstdCompressionHandler();
            _zlibHandler = new ZLibCompressionHandler();
        }

        public byte[] Decompress(byte[] data, BethesdaGameType gameType)
        {
            if (data == null || data.Length == 0) return Array.Empty<byte>();

            // 1. ZSTD ellenőrzés (Starfield-nél ez nyer)
            if (_zstdHandler.CanHandle(data))
            {
                return _zstdHandler.Decompress(data);
            }

            // 2. ZLIB ellenőrzés (Skyrim/Fallout/néha Starfield)
            if (_zlibHandler.CanHandle(data))
            {
                return _zlibHandler.Decompress(data);
            }

            // Ha egyik sem, akkor vagy már tömörítetlen, vagy ismeretlen formátum.
            // Ilyenkor logoljuk, hogy tudjuk, mi maradt ki:
            if (data.Length > 4)
            {
                System.Diagnostics.Debug.WriteLine($"[INFO] Unknown compression header: {data[0]:X2} {data[1]:X2}");
            }

            return data;
        }

        // Visszafelé kompatibilitás a paraméter nélküli hívásokhoz
        public byte[] Decompress(byte[] data) => Decompress(data, BethesdaGameType.Skyrim);
    }
}

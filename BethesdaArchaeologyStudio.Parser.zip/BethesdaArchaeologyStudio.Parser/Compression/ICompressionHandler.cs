﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BethesdaArchaeologyStudio.Parser.Compression
{
    public interface ICompressionHandler
    {
        bool CanHandle(byte[] data);

        byte[] Decompress(byte[] data);
    }
}

﻿using ICSharpCode.SharpZipLib.Zip.Compression;

public class ZLibCompressionHandler
{
    // Zlib Magic: 78 01, 78 9C, 78 DA (ezek a leggyakoribbak)
    public bool CanHandle(byte[] data)
    {
        if (data.Length < 2) return false;
        return data[0] == 0x78 && (data[1] == 0x01 || data[1] == 0x9C || data[1] == 0xDA);
    }

    public byte[] Decompress(byte[] data)
    {
        Inflater inflater = new Inflater();
        inflater.SetInput(data);

        // Becsült méret, érdemes nagyobbra venni, mint a bemenet
        byte[] buffer = new byte[data.Length * 4];
        int written = inflater.Inflate(buffer);

        return buffer.Take(written).ToArray();
    }
}
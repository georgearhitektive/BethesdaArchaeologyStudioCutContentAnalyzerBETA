// COMPREHENSIVE DIAGNOSTIC PATCH FOR PluginParser
// This module should be added alongside PluginParser.cs to help diagnose the root cause

using System;
using System.Diagnostics;
using System.IO;
using System.Collections.Generic;

namespace BethesdaArchaeologyStudio.Parser.Parser
{
    /// <summary>
    /// Diagnostics helper to trace record parsing and stream position misalignment
    /// </summary>
    public static class ParserDiagnostics
    {
        private static int _recordNumber = 0;
        private static StreamTracingWriter? _tracer;

        public static void Initialize(string logPath)
        {
            _tracer = new StreamTracingWriter(logPath);
        }

        public static void TraceHeaderRead(
            long positionBefore,
            byte[] headerBuffer,
            string signature,
            uint dataSize,
            uint flags,
            uint formId,
            int recordHeaderSize)
        {
            _recordNumber++;
            var headerHex = BitConverter.ToString(headerBuffer);
            var line = $"[REC {_recordNumber}] Pos={positionBefore:D6} HdrLen={recordHeaderSize} " +
                       $"Sig='{signature}' DS={dataSize:D8} Flags=0x{flags:X8} FID=0x{formId:X8} " +
                       $"Hex={headerHex}";
            Debug.WriteLine(line);
            _tracer?.WriteLine(line);
        }

        public static void TraceGrupSkip(long positionBefore, uint dataSize, long positionAfter)
        {
            var line = $"  [GRUP] Skip from {positionBefore:D6} + {dataSize:D8} = {positionAfter:D6}";
            Debug.WriteLine(line);
            _tracer?.WriteLine(line);
        }

        public static void TraceSignatureInvalid(
            long position,
            byte[] headerBuffer,
            string signature)
        {
            var headerHex = BitConverter.ToString(headerBuffer);
            var line = $"  [INVALID] Pos={position:D6} Sig='{signature}' Hex={headerHex} " +
                       $"ASCIIValues=[{headerBuffer[0]:D3},{headerBuffer[1]:D3},{headerBuffer[2]:D3},{headerBuffer[3]:D3}]";
            Debug.WriteLine(line);
            _tracer?.WriteLine(line);
        }

        public static void TraceResync(int offsetFound, string foundSignature)
        {
            var line = $"  [RESYNC] Found valid sig '{foundSignature}' at offset +{offsetFound}";
            Debug.WriteLine(line);
            _tracer?.WriteLine(line);
        }

        public static void TraceResyncFailed()
        {
            var line = $"  [RESYNC_FAILED] No valid signature found in scan window";
            Debug.WriteLine(line);
            _tracer?.WriteLine(line);
        }

        public class StreamTracingWriter : IDisposable
        {
            private readonly string _path;
            private StreamWriter _writer;

            public StreamTracingWriter(string path)
            {
                _path = path;
                try
                {
                    _writer = new StreamWriter(_path, append: true) { AutoFlush = true };
                }
                catch { /* Silently fail if log cannot be created */ }
            }

            public void WriteLine(string message)
            {
                try
                {
                    _writer?.WriteLine($"{DateTime.Now:HH:mm:ss.fff} {message}");
                }
                catch { /* Silently fail */ }
            }

            public void Dispose()
            {
                _writer?.Dispose();
            }
        }
    }

    /// <summary>
    /// Validation helper for record signatures
    /// </summary>
    public static class RecordSignatureValidator
    {
        // Standard TES record signatures (4-byte ASCII codes)
        private static readonly HashSet<string> KNOWN_SIGNATURES = new()
        {
            "TES4", // File header
            "GRUP", // Group/container
            "WRLD", "CELL", "ROAD", "LAND", "PGRE", "NAVI", "NAVM", // Worldspace records
            "REFR", "ACHR", "ACRE", "PHZD", "LIGHTS", // Reference records
            "ARMO", "WEAP", "AMMO", "ALCH", "INGR", "BOOK", "MISC", "APPA", // Item records
            "SPEL", "ENCH", "KEYM", "PERK", "QUST", "IDLE", // Ability/utility
            "RACE", "HAIR", "EYES", "SKIL", "MGEF", "CLAS", "FACT", "DIAL", "INFO", // Character/dialogue
            "DOOR", "FURN", "CONT", "LIGH", "STAT", "SCPT", "NPC_", "CREA", // NPC/creature
            "SOUN", "MUSC", "SLGM", "REGN", "CLMT", "WTHR", "BSGN", "LSCR", // Environment
            "LVLC", "LVLN", "LVLI", "LEVL", // Leveled lists
            "GRAS", "TREE", "FLOR", "ATMS", "WATR", "EFSH", // Flora/effects
            "EXPL", "DEBR", "SLFL", "DLBR", // Explosives/debris
            "PWMS", "PWSM", "MODL", "MSET", // Model/mesh
            
            // JAVÍTVA: Starfield specifikus rekordok bővítése a fegyverekkel (WPN_) és terminálokkal (TERM)
            "XTEL", "OMOD", "OMSA", "MATO", "EQUP", "WPN_", "TERM","ARMO", "WEAP", "AMMO",
        };

        /// <summary>
        /// Checks if the first 4 bytes of headerBuffer form a valid ASCII record signature
        /// </summary>
        public static bool IsValidSignature(byte[] headerBuffer, out string signature)
        {
            signature = "";

            if (headerBuffer == null || headerBuffer.Length < 4)
                return false;

            for (int i = 0; i < 4; i++)
            {
                byte b = headerBuffer[i];
                if ((b < 0x41 || b > 0x5A) && b != 0x5F && b != 0x30)  // Allow letters, underscore, digits
                    return false;
            }

            signature = System.Text.Encoding.ASCII.GetString(headerBuffer, 0, 4);

            return KNOWN_SIGNATURES.Contains(signature) || IsLikelyValidSignature(signature);
        }

        private static bool IsLikelyValidSignature(string sig)
        {
            foreach (char c in sig)
            {
                if (!char.IsLetterOrDigit(c) && c != '_')
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Analyzes the first 16 bytes of a header to help diagnose format issues
        /// </summary>
        public static string AnalyzeHeaderFormat(byte[] headerBuffer, int expectedHeaderSize)
        {
            if (headerBuffer.Length < 16)
                return "Buffer too small";

            var sig = System.Text.Encoding.ASCII.GetString(headerBuffer, 0, 4);
            var dataSize = System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(headerBuffer.AsSpan(4, 4));
            var field1 = System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(headerBuffer.AsSpan(8, 4));
            var field2 = System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(headerBuffer.AsSpan(12, 4));

            return $"Sig={sig} DataSize={dataSize} Field8={field1:X8} Field12={field2:X8} HdrSz={expectedHeaderSize}";
        }
    }

    /// <summary>
    /// Helper to scan for the next valid record boundary
    /// </summary>
    public static class RecordResynchronizer
    {
        // JAVÍTVA: A félbehagyott szinkronizációs metódus teljes, biztonságos megírása
        public static int ScanForNextValidSignature(FileStream fs, long badPosition, int maxScanDistance = 65536)
        {
            const int sigLen = 4;
            long savePosition = fs.Position;

            try
            {
                int scanLen = (int)Math.Min(maxScanDistance, fs.Length - badPosition);
                if (scanLen < sigLen)
                    return -1;

                byte[] window = new byte[scanLen];
                fs.Position = badPosition;
                int actualRead = fs.Read(window, 0, scanLen);

                // Végigpásztázzuk a beolvasott ablakot érvényes szignatúráért
                for (int i = 0; i <= actualRead - sigLen; i++)
                {
                    byte[] tempBuf = new byte[4];
                    Buffer.BlockCopy(window, i, tempBuf, 0, 4);

                    if (RecordSignatureValidator.IsValidSignature(tempBuf, out string foundSig))
                    {
                        fs.Position = badPosition + i;
                        ParserDiagnostics.TraceResync(i, foundSig);
                        return i; // Visszaadjuk az eltolást, ahol a tiszta rekord kezdődik
                    }
                }

                ParserDiagnostics.TraceResyncFailed();
                return -1;
            }
            finally
            {
                fs.Position = savePosition; // Visszaállítjuk a streamet az eredeti helyére
            }
        }
    }
}

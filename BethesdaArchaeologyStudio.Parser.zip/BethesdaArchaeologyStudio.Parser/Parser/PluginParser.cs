﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Buffers;
using System.Buffers.Binary;
using BethesdaArchaeologyStudio.Core.Models;
using BethesdaArchaeologyStudio.Core.Enums;
using BethesdaArchaeologyStudio.Parser.Compression;

namespace BethesdaArchaeologyStudio.Parser.Parser
{
    public class PluginParser
    {
        private const int RecordHeaderSize = 24;
        public BethesdaStringReader StringDb { get; }
        private readonly CompressionManager _compressionManager = new CompressionManager();
        private bool _isPluginLocalized = false;
        private BethesdaGameType _currentGameType;

        // Csak ezeket a rekordokat fogja ténylegesen feldolgozni a program
        private static readonly HashSet<string> TargetSignatures = new HashSet<string>
        {
            "TES4", "ARMO", "WEAP", "NPC_", "QUST", "DIAL", "INFO", "BOOK", "CELL", "EQUP", "ENCH", "AMMO", "MISC","DOOR", "STAT",
        };

        public PluginParser(BethesdaStringReader stringDb)
        {
            StringDb = stringDb;
        }

        public IEnumerable<Record> ParseFileStream(string filePath)
        {
            _currentGameType = BethesdaGameTypeDetector.Detect(filePath);
            using FileStream fs = File.OpenRead(filePath);
            byte[] headerBuffer = new byte[RecordHeaderSize];

            while (fs.Position + RecordHeaderSize <= fs.Length)
            {
                fs.ReadExactly(headerBuffer, 0, RecordHeaderSize);

                uint dataSize = BinaryPrimitives.ReadUInt32LittleEndian(headerBuffer.AsSpan(4, 4));
                uint recordFlags = BinaryPrimitives.ReadUInt32LittleEndian(headerBuffer.AsSpan(8, 4));
                uint formId = BinaryPrimitives.ReadUInt32LittleEndian(headerBuffer.AsSpan(12, 4));

                var header = new UnifiedRecordHeader
                {
                    Signature = Encoding.ASCII.GetString(headerBuffer, 0, 4),
                    DataSize = dataSize,
                    Flags = recordFlags,
                    SmartFormId = formId,
                    IsCompressed = (recordFlags & 0x00040000) != 0
                };

                // 1. JAVÍTÁS: A GRUP egy mappa. Nem ugorjuk át a méretét, hanem "belépünk" a mappába.
                if (header.Signature == "GRUP")
                {
                    continue;
                }

                // 2. JAVÍTÁS: Ha a rekord nincs a keresett listában, ugrunk a következőre (gyorsítás)
                if (!TargetSignatures.Contains(header.Signature))
                {
                    long nextPosition = fs.Position + header.DataSize;

                    if (nextPosition <= fs.Length)
                    {
                        fs.Position = nextPosition; // Átugorjuk az adatokat olvasás nélkül
                    }
                    else
                    {
                        fs.Position = fs.Length; // Biztonsági fájlvége
                    }
                    continue;
                }

                byte[] rawData = new byte[header.DataSize];
                fs.ReadExactly(rawData);
                byte[] data = rawData;

                if (header.IsCompressed)
                {
                    try
                    {
                        // 3. JAVÍTÁS: A zlib stream előtt ott a 4 bájtos uncompressed size
                        if (rawData.Length > 4)
                        {
                            var compressedStream = rawData.AsSpan(4).ToArray();
                            var decompressed = _compressionManager.Decompress(compressedStream, _currentGameType);

                            if (decompressed == null || decompressed.Length == 0)
                            {
                                System.Diagnostics.Debug.WriteLine($"[SKIPPED] Failed to decompress: {header.Signature}");
                                continue;
                            }
                            data = decompressed;
                        }
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"[CRITICAL] Decompression error in the {header.Signature} at the record: {ex.Message}");
                        continue;
                    }
                }

                var record = new Record
                {
                    Signature = header.Signature,
                    DataSize = header.DataSize,
                    Flags = header.Flags,
                    FormId = header.SmartFormId
                };

                if (record.Signature == "TES4")
                {
                    _isPluginLocalized = (record.Flags & 0x00000080) != 0;
                }

                int subPos = 0;
                ReadOnlySpan<byte> dataSpan = data.AsSpan();

                try
                {
                    while (subPos < dataSpan.Length)
                    {
                        if (subPos + 6 > dataSpan.Length) break;

                        var result = SubrecordFactory.Create(dataSpan, subPos, _currentGameType);

                        if (result.Subrecord == null || result.TotalRead <= 0) break;
                        if (subPos + result.TotalRead > dataSpan.Length) break;

                        ApplySubrecordToRecord(record, result.Subrecord);

                        var field = new Field
                        {
                            Signature = result.Subrecord.Signature,
                            RawData = result.Subrecord.Data.ToArray()
                        };

                        record.Fields ??= new List<Field>();
                        record.Fields.Add(field);

                        subPos += result.TotalRead;
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[PARSER ERROR] {ex.Message}");
                }

                // Starfield DIAL (Párbeszéd) logika megtartása
                if (_currentGameType == BethesdaGameType.Starfield && record.Signature == "DIAL")
                {
                    if (string.IsNullOrEmpty(record.EditorId) || record.EditorId.StartsWith("[ID:"))
                    {
                        record.EditorId = !string.IsNullOrEmpty(record.FullName)
                            ? record.FullName
                            : $"[DIAL FormID: {record.FormId.Value:X8}]";
                    }
                }

                // Generálunk EditorID-t azoknak a rekordoknak, amiknek gyárilag nincs
                if (string.IsNullOrWhiteSpace(record.EditorId))
                {
                    record.EditorId = $"{record.Signature}_{record.FormId.Value:X8}";
                }

                // Csak a TES4 (fejléc) rekordot hagyjuk ki a listából, minden mást visszaadunk
                if (record.Signature != "TES4")
                {
                    yield return record;
                }
            }
        }

        private string GetZString(ReadOnlySpan<byte> data)
        {
            if (data.IsEmpty) return string.Empty;

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            // 1. ELLENŐRZÉS: UTF-16 (Wide Char) detektálás
            // Ha a 2. bájt null (pl. 'A' 00), akkor 99%, hogy UTF-16/Unicode
            bool isUnicode = data.Length >= 2 && data[1] == 0;

            Encoding encoding;
            if (isUnicode)
            {
                // Ha UTF-16, használjunk Unicode-ot (Little Endian)
                return Encoding.Unicode.GetString(data).TrimEnd('\0');
            }
            else
            {
                // Egyébként marad a játék-specifikus kódolás
                encoding = _currentGameType switch
                {
                    BethesdaGameType.SkyrimSE => Encoding.UTF8,
                    BethesdaGameType.Fallout4 => Encoding.UTF8,
                    BethesdaGameType.Starfield => Encoding.UTF8,
                    _ => Encoding.GetEncoding(1250) // Magyar kódlap a régebbieknek
                };
            }

            try
            {
                // A null-byte-os levágást csak akkor csináljuk, ha nem Unicode, 
                // mert a Unicode-ban a null-t a 2 bájtos 00 00 jelenti.
                if (!isUnicode)
                {
                    int nullIndex = data.IndexOf((byte)0);
                    if (nullIndex != -1) data = data.Slice(0, nullIndex);
                }

                return encoding.GetString(data);
            }
            catch
            {
                return "Encoding Error";
            }
        }

        private void ApplySubrecordToRecord(Record record, Subrecord sub)
        {
            if (sub.Data.IsEmpty) return;

            switch (sub.Signature)
            {
                case "EDID":
                    record.EditorId = GetZString(sub.Data.Span);
                    break;

                case "NAM1":
                    if (sub.Data.Length == 4)
                    {
                        uint stringId = BinaryPrimitives.ReadUInt32LittleEndian(sub.Data.Span);

                        // 1. Ha az ID 0, akkor beállítjuk a kért szöveget
                        if (stringId == 0)
                        {
                            record.FullName = "There is no dialogue involved in this!";
                            break;
                        }

                        string? resolved = StringDb.GetIlString(stringId);
                        if (!string.IsNullOrEmpty(resolved))
                        {
                            record.FullName = resolved;
                        }
                        else
                        {
                            record.FullName = $"[ID: 0x{stringId:X8}]";
                        }
                        break;
                    }

                    record.FullName = GetZString(sub.Data.Span);
                    break;

                case "FULL":
                case "DESC":
                    if (sub.Data.Length == 4)
                    {
                        uint stringId = BinaryPrimitives.ReadUInt32LittleEndian(sub.Data.Span);

                        // 2. Ha az ID 0, kontextustól függően barátságos szöveget adunk vissza
                        if (stringId == 0)
                        {
                            if (sub.Signature == "DESC")
                            {
                                record.FullName = "There is no description for this!";
                            }
                            else
                            {
                                record.FullName = "There is no dialogue involved in this!";
                            }
                            break;
                        }

                        string? resolved = null;
                        if (sub.Signature == "DESC") resolved = StringDb.GetDlString(stringId);
                        else resolved = StringDb.GetString(stringId);

                        if (!string.IsNullOrEmpty(resolved))
                        {
                            record.FullName = resolved;
                        }
                        else
                        {
                            record.FullName = $"[Missing text ID: 0x{stringId:X8}]";
                        }
                        break;
                    }

                    string rawText = GetZString(sub.Data.Span);

                    if (string.IsNullOrWhiteSpace(rawText) ||
                        rawText.Contains('?') ||
                        rawText.Contains('\uFFFD'))
                    {
                        record.FullName = $"[{sub.Signature}: Binary data]";
                    }
                    else
                    {
                        record.FullName = rawText;
                    }
                    break;
                case "DATA":
                    // A DATA subrecord szerkezete játékonként kis mértékben eltérhet, de az első 8 bájt
                    // a legtöbb esetben univerzális (WEAP és ARMO esetén is):
                    // 0-4 bájt: Érték (Int32 / UInt32)
                    // 4-8 bájt: Súly (Float / Single)
                    if (record.Signature == "ARMO" || record.Signature == "WEAP")
                    {
                        if (sub.Data.Length >= 8)
                        {
                            // Érték beolvasása (4 bájt)
                            record.Value = BinaryPrimitives.ReadUInt32LittleEndian(sub.Data.Span.Slice(0, 4));

                            // Súly beolvasása (4 bájt, lebegőpontos szám)
                            record.Weight = BitConverter.ToSingle(sub.Data.Span.Slice(4, 4));
                        }

                        // Ha Fegyver (WEAP) és elég hosszú a DATA blokk, a 8. bájttól jön a sebzés
                        if (record.Signature == "WEAP" && sub.Data.Length >= 10)
                        {
                            record.Damage = BinaryPrimitives.ReadUInt16LittleEndian(sub.Data.Span.Slice(8, 2));
                        }
                    }
                    break;

                case "EITM":
                    if (sub.Data.Length == 4)
                    {
                        uint formId = BinaryPrimitives.ReadUInt32LittleEndian(sub.Data.Span);
                        if (formId != 0)
                        {
                            record.RawEnchantmentFormId = formId; // Eltároljuk a nyers ID-t a kereséshez
                            record.EnchantmentId = $"[FormID: 0x{formId:X8}]"; // Ez marad a fallback, ha nem találjuk meg
                        }
                    }
                    break;

                case "NAM0":
                    if (sub.Data.Length == 4)
                    {
                        uint formId = BinaryPrimitives.ReadUInt32LittleEndian(sub.Data.Span);
                        if (formId != 0)
                        {
                            record.RawAmmoFormId = formId; // Eltároljuk a nyers ID-t a kereséshez
                            record.AmmoId = $"[FormID: 0x{formId:X8}]"; // Fallback
                        }
                    }
                    break;

            }
        
        }

    }
}
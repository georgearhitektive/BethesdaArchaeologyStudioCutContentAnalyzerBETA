﻿using System;
using System.Buffers.Binary;
using BethesdaArchaeologyStudio.Core.Models;
using BethesdaArchaeologyStudio.Core.Enums;

namespace BethesdaArchaeologyStudio.Parser.Parser
{
    public static class SubrecordFactory
    {
        public static (Subrecord? Subrecord, int TotalRead) Create(ReadOnlySpan<byte> dataSpan, int position, BethesdaGameType gameType)
        {
            // 1. Alap standard fejléc méret vizsgálat (4 bájt szignatúra + 2 bájt hossz)
            if (position < 0 || position + 6 > dataSpan.Length)
                return (null, 0);

            // Szignatúra kinyerése
            string signature = System.Text.Encoding.ASCII.GetString(dataSpan.Slice(position, 4));

            if (!IsPrintable(signature))
                return (null, 0);

            // Alapértelmezett hossz beolvasása (2 bájt)
            ushort standardLength = BinaryPrimitives.ReadUInt16LittleEndian(dataSpan.Slice(position + 4, 2));

            int dataOffset = 6;
            long actualLength = standardLength;

            // Minden modern 64 bites motor (SkyrimSE, Fallout 4, Starfield) 
            // használja az óriás subrecordokat, ha a standardLength értéke 0xFFFF!
            bool isModernEngine = gameType == BethesdaGameType.SkyrimSE ||
                                  gameType == BethesdaGameType.Fallout4 ||
                                  gameType == BethesdaGameType.Starfield;

            if (isModernEngine && standardLength == 0xFFFF)
            {
                if (position + 10 > dataSpan.Length)
                    return (null, 0);

                actualLength = BinaryPrimitives.ReadUInt32LittleEndian(dataSpan.Slice(position + 6, 4));
                dataOffset = 10;
            }

            // BIZTONSÁGI ELLENŐRZÉS ÉS DIAGNOSZTIKA
            if (actualLength < 0 || position + dataOffset + actualLength > dataSpan.Length)
            {
                // Ha a szignatúra értelmezhetetlen karaktereket tartalmaz, az egyértelműen jelzi, 
                // hogy még tömörített adatot kapott meg a factory!
                bool isGarbageSignature = string.IsNullOrEmpty(signature) ||
                                          signature.Length != 4 ||
                                          char.IsControl(signature[0]) ||
                                          char.IsControl(signature[1]);

                System.Diagnostics.Debug.WriteLine(
                    $"""
                    [SUBRECORD FACTORY HIBA] 
                    Pozíció: {position}
                    Feltételezett Szignatúra: '{signature}' {(isGarbageSignature ? "(HIBA: Nem szöveges adat!)" : "")}
                    Beolvasni kívánt méret: {actualLength} byte
                    Rendelkezésre álló buffer: {dataSpan.Length - position - dataOffset} byte
                    ----------------------------------------------------
                    """
                );

                return (null, 0);
            }

            try
            {
                // Kivágjuk a subrecord tényleges adatbájtjait
                byte[] subData = dataSpan.Slice(position + dataOffset, (int)actualLength).ToArray();

                var subRecord = new Subrecord
                {
                    Signature = signature,
                    DataSize = (uint)actualLength,
                    Data = new ReadOnlyMemory<byte>(subData)
                };

                int totalRead = dataOffset + (int)actualLength;
                return (subRecord, totalRead);
            }
            catch (ArgumentOutOfRangeException)
            {
                return (null, 0);
            }
        }
        private static bool IsPrintable(string sig)
        {
            foreach (char c in sig)
            {
                if (c < 32 || c > 126) return false;
            }
            return true;
        }
    }
}

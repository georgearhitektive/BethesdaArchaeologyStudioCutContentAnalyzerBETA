﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Buffers;
using BethesdaArchaeologyStudio.Core.Enums;

namespace BethesdaArchaeologyStudio.Parser.Parser
{
    public sealed class BethesdaReader : IDisposable
    {
        // Három különálló szótár az ütközések elkerülésére
        private readonly Dictionary<uint, string> _strings = new Dictionary<uint, string>();
        private readonly Dictionary<uint, string> _dlStrings = new Dictionary<uint, string>();
        private readonly Dictionary<uint, string> _ilStrings = new Dictionary<uint, string>();

        private bool _isDisposed;

        /// <summary>
        /// Szuper kényelmes metódus: betölti az alap .strings mellett a .dlstrings és .ilstrings fájlokat is, ha léteznek.
        /// </summary>
        public void LoadAll(string basePath, BethesdaGameType gameType)
        {
            ThrowIfDisposed();

            if (basePath.EndsWith(".strings", StringComparison.OrdinalIgnoreCase) ||
                basePath.EndsWith(".dlstrings", StringComparison.OrdinalIgnoreCase) ||
                basePath.EndsWith(".ilstrings", StringComparison.OrdinalIgnoreCase))
            {
                basePath = Path.ChangeExtension(basePath, null);
            }

            Load(basePath + ".strings", gameType);
            Load(basePath + ".dlstrings", gameType);
            Load(basePath + ".ilstrings", gameType);
        }

        public void Load(string filePath, BethesdaGameType gameType)
        {
            ThrowIfDisposed();
            if (!File.Exists(filePath)) return;

            string extension = Path.GetExtension(filePath).ToLowerInvariant();
            bool isStringsFile = extension == ".strings";
            bool isStarfield = gameType == BethesdaGameType.Starfield;

            // Kiterjesztés alapján a megfelelő szótárba irányítjuk az adatokat
            Dictionary<uint, string> targetDict = extension switch
            {
                ".dlstrings" => _dlStrings,
                ".ilstrings" => _ilStrings,
                _ => _strings
            };

            // JAVÍTVA: Starfieldnél minden 12 bájt. Régebbi játékoknál csak a dl/il 12 bájt, a .strings 10.
            int entryHeaderSize = (isStarfield || !isStringsFile) ? 12 : 10;

            // JAVÍTVA: Starfield = UTF-16 (Unicode), Skyrim/FO4 = UTF-8
            Encoding encoding = isStarfield ? Encoding.Unicode : Encoding.UTF8;

            using var fs = File.OpenRead(filePath);

            // Fejléc beolvasása (12 bájt)
            Span<byte> header = stackalloc byte[12];
            fs.ReadExactly(header);

            uint stringCount = BitConverter.ToUInt32(header.Slice(0, 4));

            // JAVÍTVA: A puffer bérlése lokális változóba történik
            int entriesSize = (int)(stringCount * entryHeaderSize);
            byte[] entriesBuffer = ArrayPool<byte>.Shared.Rent(entriesSize);

            try
            {
                fs.ReadExactly(entriesBuffer.AsSpan(0, entriesSize));
                long dataBlockStart = fs.Position;

                // Memória optimalizáció: közvetlenül a pufferből olvassuk az értékeket, felesleges köztes tömbök nélkül!
                for (int i = 0; i < stringCount; i++)
                {
                    int pos = i * entryHeaderSize;
                    uint id = BitConverter.ToUInt32(entriesBuffer, pos);
                    uint offset = BitConverter.ToUInt32(entriesBuffer, pos + 4);

                    uint length;
                    if (entryHeaderSize == 12)
                    {
                        length = BitConverter.ToUInt32(entriesBuffer, pos + 8);
                    }
                    else
                    {
                        length = BitConverter.ToUInt16(entriesBuffer, pos + 8);
                    }

                    if (length == 0)
                    {
                        targetDict[id] = string.Empty;
                        continue;
                    }

                    byte[] stringBuffer = ArrayPool<byte>.Shared.Rent((int)length);
                    try
                    {
                        fs.Position = dataBlockStart + offset;
                        fs.ReadExactly(stringBuffer.AsSpan(0, (int)length));

                        string text = encoding.GetString(stringBuffer.AsSpan(0, (int)length)).Replace("\0", "");
                        targetDict[id] = text;
                    }
                    finally
                    {
                        ArrayPool<byte>.Shared.Return(stringBuffer);
                    }
                }
            }
            finally
            {
                // JAVÍTVA: Az átmeneti puffert AZONNAL visszaadjuk a poolba, nem várunk a Dispose-ig!
                ArrayPool<byte>.Shared.Return(entriesBuffer);
            }
        }

        // --- BIZTONSÁGOS LEKÉRDEZŐK ---
        public string? GetString(uint id) => _strings.TryGetValue(id, out var text) ? text : null;
        public string? GetDlString(uint id) => _dlStrings.TryGetValue(id, out var text) ? text : GetString(id);
        public string? GetIlString(uint id) => _ilStrings.TryGetValue(id, out var text) ? text : GetString(id);

        private void ThrowIfDisposed() => ObjectDisposedException.ThrowIf(_isDisposed, this);

        public void Dispose()
        {
            if (_isDisposed) return;
            _strings.Clear();
            _dlStrings.Clear();
            _ilStrings.Clear();
            _isDisposed = true;
        }
    }
}
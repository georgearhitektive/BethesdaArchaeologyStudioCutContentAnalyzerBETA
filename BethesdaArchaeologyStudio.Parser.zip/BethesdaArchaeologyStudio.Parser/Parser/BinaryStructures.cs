﻿using System;

namespace BethesdaArchaeologyStudio.Parser.Parser
{
    /// <summary>
    /// Egységesített rekord fejléc, amit a PluginParser játékfüggetlenül tud kezelni.
    /// Támogatja a 20 és 24 bájtos fejléc-struktúrákat (TES4 vs Starfield).
    /// </summary>
    public class UnifiedRecordHeader
    {
        public string Signature { get; set; } = string.Empty; // 4 karakteres azonosító (pl. "QUST")
        public uint DataSize { get; set; }                     // A rekord adatblokkjának mérete
        public ulong Flags { get; set; }                      // 64-bitesre bővítve, hogy a Starfield is elférjen[cite: 9]
        public uint SmartFormId { get; set; }                 // Egyedi azonosító[cite: 9]

        // Segédmező a fejléc teljes hosszának követésére a stream olvasáskor[cite: 9]
        public int HeaderSize { get; set; }
        public bool IsCompressed { get; internal set; }
    }

    /// <summary>
    /// Egységesített almező (Subrecord) fejléc.
    /// A Starfield és korábbi játékok subrecordjainak egységes kezelésére[cite: 9].
    /// </summary>
    public class UnifiedSubRecordHeader
    {
        public string Signature { get; set; } = string.Empty; // 4 karakteres azonosító (pl. "EDID")[cite: 9]
        public uint DataSize { get; set; }                    // 32-bitesre bővítve a Starfield óriásmezői miatt[cite: 9]
    }

    /// <summary>
    /// Segédosztály a bináris adatok kényelmes olvasásához a stream pozíciók alapján.
    /// </summary>
    public static class BinaryHeaderHelper
    {
        public const int StandardHeaderSize = 20;
        public const int StarfieldHeaderSize = 24;
    }
}
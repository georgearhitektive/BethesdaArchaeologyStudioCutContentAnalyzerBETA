﻿using System.Collections.Generic;
using System.Linq;
using BethesdaArchaeologyStudio.Core.Interfaces;
using BethesdaArchaeologyStudio.Core.Models;

namespace BethesdaArchaeologyStudio.Core.Services
{
    public class CutDialogueAnalyzer : IAnalyzer
    {
        public string Name => "Clipped and Orphaned Dialogue Analyzer";
        public string Description => "It filters out conversations left in the game files that are never heard due to the lack of active references.";

        public IEnumerable<Finding> Analyze(IEnumerable<Record> database)
        {
            var findings = new List<Finding>();
            var dbList = database?.ToList() ?? new List<Record>();

            // Összes kimenő hivatkozás kigyűjtése a halmazba a gyors kereséshez
            var activeReferences = dbList
                .Where(r => r != null && r.OutgoingReferences != null)
                .SelectMany(r => r.OutgoingReferences)
                .Select(refs => refs.Target)
                .ToHashSet();

            var dialogueRecords = dbList.Where(r => r != null && (r.Signature == "DIAL" || r.Signature == "INFO")).ToList();

            foreach (var rec in dialogueRecords)
            {
                string editorIdLower = (rec.EditorId ?? string.Empty).ToLowerInvariant();
                string displayName = !string.IsNullOrWhiteSpace(rec.FullName) ? rec.FullName : "[No text content.]";

                // Ha egy dialógusra nem hivatkozik semmi, vagy az azonosítója gyanús
                bool isUnreferenced = !activeReferences.Contains(rec.FormId);
                bool isTest = editorIdLower.Contains("test") ||
                              editorIdLower.Contains("dummy") ||
                              editorIdLower.Contains("unused") ||
                              editorIdLower.Contains("cut");

                if (isUnreferenced || isTest)
                {
                    findings.Add(new Finding
                    {
                        Title = $"Cut Dialogue ({rec.Signature})",
                        Description = $"The '{rec.EditorId}' ({displayName}) A dialogue element exists in the file, but due to the lack of active references, it never plays in the game.",
                        Category = "Cut Content - Dialogue",
                        Confidence = isTest ? 0.98f : 0.85f,
                        TargetRecord = rec,
                        AnalyzerName = this.Name
                    });
                }
            }
            return findings;
        }
    }
}
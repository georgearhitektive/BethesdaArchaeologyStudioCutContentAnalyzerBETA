﻿using System.Collections.Generic;
using System.Linq;
using BethesdaArchaeologyStudio.Core.Interfaces;
using BethesdaArchaeologyStudio.Core.Models;


namespace BethesdaArchaeologyStudio.Core.Services
{
    public class DeletedCellAnalyzer : IAnalyzer
    {
        public string Name => "Deleted and Closed Cell Finder";
        public string Description => "Detects interior spaces within the game file that are marked as \"Deleted\" or \"Ignored,\" or are enclosed without a physical entrance.";

        public IEnumerable<Finding> Analyze(IEnumerable<Record> database)
        {
            var findings = new List<Finding>();
            var dbList = database?.ToList() ?? new List<Record>();

            // JAVÍTVA: A szótár kulcsa most már helyesen a te SmartFormId struktúrád!
            // (Ha a projektedben csupa nagybetűvel írod, akkor írd át SmartFormID-ra)
            var recordMap = new Dictionary<SmartFormId, Record>();
            foreach (var r in dbList)
            {
                if (r != null && !recordMap.ContainsKey(r.FormId))
                {
                    recordMap[r.FormId] = r;
                }
            }

            var allCells = dbList
                .Where(r => r != null && r.Signature == "CELL")
                .ToList();

            // Teleport ajtók és kapuk célobjektumainak feloldása a SmartFormId szótárból
            var activeTeleportTargets = dbList
                .Where(r => r != null && r.Signature == "REFR" && r.OutgoingReferences != null)
                .SelectMany(r => r.OutgoingReferences)
                .Select(o => { recordMap.TryGetValue(o.Target, out var targetRec); return targetRec; })
                .Where(targetRec => targetRec != null && targetRec.Signature == "CELL")
                .Select(targetRec => targetRec.FormId)
                .ToHashSet();

            foreach (var cell in allCells)
            {
                if (cell == null) continue;

                string editorIdLower = (cell.EditorId ?? string.Empty).ToLowerInvariant();
                string displayName = !string.IsNullOrWhiteSpace(cell.FullName) ? cell.FullName : "[Anonymous Cell]";

                // A) Kiszűrés EditorID vagy jellemzők alapján (pl. teszt szobák)
                bool isTestCell = editorIdLower.Contains("test") ||
                                  editorIdLower.Contains("holdingcell") ||
                                  editorIdLower.Contains("warehouse") ||
                                  editorIdLower.Contains("dummy") ||
                                  editorIdLower.Contains("debug");

                if (isTestCell)
                {
                    findings.Add(new Finding
                    {
                        Title = "Development Test Cell / Warehouse",
                        Description = $"The '{cell.EditorId}' ({displayName}) an internal testing or storage area that developers used for storing or testing objects, and which remained in the files.",
                        Category = "Cut Content - Cell",
                        Confidence = 0.95f,
                        TargetRecord = cell,
                        AnalyzerName = this.Name
                    });
                    continue;
                }

                // B) Logikailag elvágott, megközelíthetetlen cellák
                bool isInterior = cell.EditorId != null && !editorIdLower.Contains("wilderness");

                if (isInterior && !activeTeleportTargets.Contains(cell.FormId))
                {
                    findings.Add(new Finding
                    {
                        Title = "Inaccessible Location (Unreachable Interior)",
                        Description = $"The '{cell.EditorId}' ({displayName}) an interior space exists in the file, but no door or teleporter leads into it. It is likely a completely cut location.",
                        Category = "Cut Content - Cell",
                        Confidence = 0.88f,
                        TargetRecord = cell,
                        AnalyzerName = this.Name
                    });
                }
            }

            return findings;
        }
    }
}
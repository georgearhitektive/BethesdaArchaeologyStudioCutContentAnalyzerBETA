﻿using System.Collections.Generic;
using System.Linq;
using BethesdaArchaeologyStudio.Core.Interfaces;
using BethesdaArchaeologyStudio.Core.Models;

namespace BethesdaArchaeologyStudio.Core.Services
{
    public class UnusedQuestAnalyzer : IAnalyzer
    {
        public string Name => "\r\nIncomplete and Cut Quest Inspector";
        public string Description => "Filters out cut quests that lack references, are in an incomplete state, or lack dialogue.";

        public IEnumerable<Finding> Analyze(IEnumerable<Record> database)
        {
            var findings = new List<Finding>();
            var dbList = database?.ToList() ?? new List<Record>();

            var allQuests = dbList.Where(r => r != null && r.Signature == "QUST").ToList();

            // Összes kimenő hivatkozás kigyűjtése
            var allReferences = dbList
                .Where(r => r != null && r.OutgoingReferences != null)
                .SelectMany(r => r.OutgoingReferences)
                .Select(refs => refs.Target)
                .ToHashSet();

            foreach (var quest in allQuests)
            {
                if (quest == null) continue;

                string editorIdLower = (quest.EditorId ?? string.Empty).ToLowerInvariant();
                string displayName = !string.IsNullOrWhiteSpace(quest.FullName) ? quest.FullName : "[No public name]";

                // CÉLPONT 1: Teljesen elárvult küldetés (Egyetlen script vagy zóna sem hivatkozik rá)
                if (!allReferences.Contains(quest.FormId))
                {
                    bool isTestName = editorIdLower.Contains("test") ||
                                      editorIdLower.Contains("cut") ||
                                      editorIdLower.Contains("dummy") ||
                                      editorIdLower.Contains("unused");

                    findings.Add(new Finding
                    {
                        Title = "Cut Content QUST",
                        Description = $"The '{quest.EditorId}' ({displayName}) No external record or script references the mission. It remains in the file but is completely inaccessible.",
                        Category = "Unused Quest",
                        Confidence = isTestName ? 0.98f : 0.90f,
                        TargetRecord = quest,
                        AnalyzerName = this.Name
                    });

                    continue;
                }

                // CÉLPONT 2: Félbehagyott / Fejlesztői Teszt küldetés
                if (string.IsNullOrEmpty(quest.FullName) ||
                    editorIdLower.Contains("test") ||
                    editorIdLower.Contains("cut") ||
                    editorIdLower.Contains("dummy") ||
                    editorIdLower.Contains("unused"))
                {
                    string specificReason = string.IsNullOrEmpty(quest.FullName)
                        ? "the mission does not have a public name visible to players (the FULL subrecord is missing)"
                        : "Developers used it for internal testing or as a prototype, based on the EditorID.";

                    findings.Add(new Finding
                    {
                        Title = "Unfinished / Test Mission",
                        Description = $"The '{quest.EditorId}' mission is suspicious because {specificReason}, thus presumably inactive or incomplete content.",
                        Category = "Incomplete Content",
                        Confidence = 0.85f,
                        TargetRecord = quest,
                        AnalyzerName = this.Name
                    });
                }
            }

            return findings;
        }
    }
}
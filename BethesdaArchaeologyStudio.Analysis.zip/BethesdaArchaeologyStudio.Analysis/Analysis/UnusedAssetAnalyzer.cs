﻿using System.Collections.Generic;
using System.Linq;
using BethesdaArchaeologyStudio.Core.Interfaces;
using BethesdaArchaeologyStudio.Core.Models;

namespace BethesdaArchaeologyStudio.Core.Services
{
    public class UnusedAssetAnalyzer : IAnalyzer
    {
        public string Name => "Unused Characters and Equipment Inspector";
        public string Description => "It finds NPCs, armor, weapons, and books that were left in the file but not placed in the game world.";

        public IEnumerable<Finding> Analyze(IEnumerable<Record> database)
        {
            var findings = new List<Finding>();
            var dbList = database?.ToList() ?? new List<Record>();

            // Összegyűjtjük azokat a FormId-kat, amik le vannak helyezve a világba (REFR)
            var activeReferences = dbList
                .Where(r => r != null && r.OutgoingReferences != null)
                .SelectMany(r => r.OutgoingReferences)
                .Select(refs => refs.Target)
                .ToHashSet();

            foreach (var record in dbList)
            {
                if (record == null) continue;

                string editorIdLower = (record.EditorId ?? string.Empty).ToLowerInvariant();
                string displayName = !string.IsNullOrWhiteSpace(record.FullName) ? record.FullName : "[No Name]";

                // 1. VÁGOTT NPC-K VIZSGÁLATA
                if (record.Signature == "NPC_")
                {
                    if (!activeReferences.Contains(record.FormId) || editorIdLower.Contains("test"))
                    {
                        findings.Add(new Finding
                        {
                            Title = "Unused / Cut NPC",
                            Description = $"The '{record.EditorId}' ({displayName}) The character is in the file but is not placed in any zone, nor is it part of any active scene.",
                            Category = "Cut NPC",
                            Confidence = 0.95f,
                            TargetRecord = record,
                            AnalyzerName = this.Name
                        });
                    }
                }

                // 2. VÁGOTT PÁNCÉLOK / SZKAFANDEREK VIZSGÁLATA (Skyrim: ARMO | Starfield: EQUP)
                else if (record.Signature == "ARMO" || record.Signature == "EQUP")
                {
                    if (!activeReferences.Contains(record.FormId) || editorIdLower.Contains("test"))
                    {
                        string displayTitle = record.Signature == "EQUP" ? "Covert / Test Equipment (Cut Equipment)" : "Hidden / Test Armor (Cut Armor)";
                        string typeWord = record.Signature == "EQUP" ? "\r\nspacesuit/equipment" : "armor";

                        findings.Add(new Finding
                        {
                            Title = displayTitle,
                            Description = $"The '{record.EditorId}' ({displayName}) {typeWord} It cannot be obtained legitimately in the game, does not appear in loot lists, and is not worn by NPCs.",
                            Category = "Cut Equipment",
                            Confidence = 0.90f,
                            TargetRecord = record,
                            AnalyzerName = this.Name
                        });
                    }
                }

                // 3. VÁGOTT FEGYVEREK VIZSGÁLATA (Skyrim: WEAP | Starfield: WPN_)
                else if (record.Signature == "WEAP" || record.Signature == "WPN_")
                {
                    if (!activeReferences.Contains(record.FormId) || editorIdLower.Contains("test"))
                    {
                        findings.Add(new Finding
                        {
                            Title = "Unused Weapon",
                            Description = $"The '{record.EditorId}' ({displayName}) the weapon exists as an item in the file, but it is not assigned to any chest or vendor.",
                            Category = "Cut Equipment",
                            Confidence = 0.92f,
                            TargetRecord = record,
                            AnalyzerName = this.Name
                        });
                    }
                }

                // 4. KIVÁGOTT KÖNYVEK ÉS JEGYZETEK (BOOK)
                else if (record.Signature == "BOOK")
                {
                    if (!activeReferences.Contains(record.FormId) || editorIdLower.Contains("test") || editorIdLower.Contains("cut"))
                    {
                        findings.Add(new Finding
                        {
                            Title = "Cut-out Book / Notebook (Unused Book)",
                            Description = $"The '{record.EditorId}' ({displayName}) \r\nA book or note exists among the files but is not placed anywhere in the explorable world.",
                            Category = "Cut Item",
                            Confidence = 0.90f,
                            TargetRecord = record,
                            AnalyzerName = this.Name
                        });
                    }
                }
            }

            return findings;
        }
    }
}
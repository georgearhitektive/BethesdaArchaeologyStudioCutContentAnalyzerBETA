﻿using System.Collections.Generic;
using System.Linq;
using BethesdaArchaeologyStudio.Core.Interfaces;
using BethesdaArchaeologyStudio.Core.Models;

namespace BethesdaArchaeologyStudio.Core.Services
{
    public class UnreachableConditionAnalyzer : IAnalyzer
    {
        public string Name => "Logically Unreachable Condition Checker";
        public string Description => "It filters out records that can never be activated due to conflicting logical conditions.";

        public IEnumerable<Finding> Analyze(IEnumerable<Record> database)
        {
            var findings = new List<Finding>();
            var dbList = database?.ToList() ?? new List<Record>();

            foreach (var record in dbList)
            {
                if (record == null || record.Conditions == null || record.Conditions.Count < 2)
                    continue;

                var levelConditions = record.Conditions.Where(c => c != null && c.FunctionName == "GetLevel").ToList();

                if (levelConditions.Count >= 2)
                {
                    var greaterThan = levelConditions.FirstOrDefault(c => c.ComparisonOperator == 2 || c.ComparisonOperator == 3);
                    var lessThan = levelConditions.FirstOrDefault(c => c.ComparisonOperator == 4 || c.ComparisonOperator == 5);

                    if (greaterThan != null && lessThan != null)
                    {
                        if (greaterThan.ComparisonValue > lessThan.ComparisonValue)
                        {
                            string displayName = !string.IsNullOrWhiteSpace(record.FullName) ? record.FullName : "[No Name]";
                            string editorId = !string.IsNullOrWhiteSpace(record.EditorId) ? record.EditorId : "[No EditorID]";

                            findings.Add(new Finding
                            {
                                Title = "Mathematically Unattainable Record (Paradox)",
                                Description = $"The '{editorId}' ({displayName}) The record contains a set of conditions that can never be met. The player's level would simultaneously need to be higher than {greaterThan.ComparisonValue} and smaller than {lessThan.ComparisonValue}.",
                                Category = "Logical Paradox",
                                Confidence = 0.99f,
                                TargetRecord = record,
                                AnalyzerName = this.Name
                            });
                        }
                    }
                }
            }

            return findings;
        }
    }
}
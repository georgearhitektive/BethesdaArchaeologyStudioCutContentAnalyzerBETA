﻿using System;
using System.Collections.Generic;
using BethesdaArchaeologyStudio.Core.Interfaces;
using BethesdaArchaeologyStudio.Core.Models;
using BethesdaArchaeologyStudio.Core;

namespace BethesdaArchaeologyStudio.Analysis.Analysis
{
    public class AnalysisEngine
    {
        public List<IAnalyzer> Analyzers { get; set; } = new List<IAnalyzer>();

        public List<Finding> RunAllAnalyses(IEnumerable<Record> database)
        {
            var allFindings = new List<Finding>();

            // 1. OPTIMALIZÁLÁS: Egyetlen egyszer olvassuk be az adatbázist (Single-Pass)
            // és egy könnyített, megszűrt listát építünk a memóriában.
            var lightWeightRecords = new List<Record>();

            foreach (var record in database)
            {
                // RAM-KÍMÉLŐ SZŰRÉS: A LAND (tájegység) és NAVM (navigációs háló) rekordok 
                // teszik ki a Bethesda fájlok 90%-át. Mivel a küldetés-, dialógus- és cellaelemzőknek 
                // ezekre nincs szükségük, be se engedjük őket a memóriába!
                if (record.Signature == "LAND" || record.Signature == "NAVM")
                {
                    continue;
                }

                lightWeightRecords.Add(record);
            }

            // Ha az adatbázis teljesen üres volt, nincs mit elemezni
            if (lightWeightRecords.Count == 0) return allFindings;

            // 2. OPTIMALIZÁLÁS: Az elemzőknek már ezt a memóriában lévő, 
            // megtisztított és villámgyors listát adjuk át. Így nem nyitogatják újra a SQLite-ot.
            foreach (var analyzer in Analyzers)
            {
                try
                {
                    // Átadjuk a pillekönnyű listát. Ha az analyzer belső kódja meg hívná a .ToList()-et, 
                    // az sem fogja megborítani a RAM-ot, mert a nehéz rekordok már nincsenek benne.
                    var results = analyzer.Analyze(lightWeightRecords);
                    if (results != null)
                    {
                        allFindings.AddRange(results);
                    }
                }
                catch (Exception ex)
                {
                    // Ha az egyik elemző hibára futna egy sérült rekord miatt, 
                    // a többi elemző még le tud futni, és a program sem fagy ki.
                    System.Diagnostics.Debug.WriteLine($"Error in the {analyzer.GetType().Name} while running: {ex.Message}");
                }
            }

            // Segítünk a Garbage Collector-nak azonnal felszabadítani a szűrt listát
            lightWeightRecords.Clear();
            lightWeightRecords = null;

            return allFindings;
        }
    }
}
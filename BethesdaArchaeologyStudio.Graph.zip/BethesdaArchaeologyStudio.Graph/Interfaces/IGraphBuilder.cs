﻿// Interfaces/IGraphBuilder.cs
using System.Collections.Generic;
using BethesdaArchaeologyStudio.Core.Models;

namespace BethesdaArchaeologyStudio.Core.Interfaces
{
    public interface IGraphBuilder
    {
        /// <summary>
        /// Összeköti a rekordokat a mezőikben található FormID-k alapján, kiépítve a tudásgráfot.
        /// </summary>
        void BuildGraph(IEnumerable<Record> allRecords);
    }
}
﻿using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Linq;
using BethesdaArchaeologyStudio.Core.Interfaces;
using BethesdaArchaeologyStudio.Core.Models;
using BethesdaArchaeologyStudio.Core.Enums;

namespace BethesdaArchaeologyStudio.Core.Services
{
    public class GraphBuilder : IGraphBuilder
    {
        public void BuildGraph(IEnumerable<Record> allRecords, string? targetSmartFormIdString = null)
        {
            if (allRecords == null) return;

            // Kulcs: Típusos SmartFormId (mivel struct, az érték-alapú összehasonlítás automatikusan működik!)
            var recordMap = new Dictionary<SmartFormId, Record>();

            foreach (var record in allRecords)
            {
                // JAVÍTVA: Mivel a FormId egy struct, nem lehet null! 
                // Azt ellenőrizzük, hogy a rekord létezik-e, és a FormId nem üres (0) azonosító.
                if (record != null && record.FormId.Value != 0)
                {
                    // Ez a sor most már hibátlanul lefordul és fut!
                    recordMap[record.FormId] = record;
                }
            }

            foreach (var sourceRecord in allRecords)
            {
                if (sourceRecord?.Fields == null) continue;

                sourceRecord.OutgoingReferences ??= new List<Reference>();
                sourceRecord.OutgoingReferences.Clear();

                foreach (var field in sourceRecord.Fields)
                {
                    if (field == null || field.RawData == null || field.RawData.Length < 4) continue;

                    if (IsPotentialReferenceField(field.Signature, field.RawData, sourceRecord.Signature))
                    {
                        uint targetVal = BinaryPrimitives.ReadUInt32LittleEndian(field.RawData);

                        if (targetVal == 0 || targetVal == uint.MaxValue) continue;

                        // JAVÍTVA: Kihasználjuk az implicit operátort, amit a SmartFormId-ban írtál!
                        // Az uint automatikusan átalakul SmartFormId-vá.
                        SmartFormId targetId = targetVal;

                        if (recordMap.TryGetValue(targetId, out var targetRecord))
                        {
                            field.Type = FieldType.FormId;

                            Reference edge = new Reference
                            {
                                Source = sourceRecord.FormId,
                                Target = targetRecord.FormId,
                                Context = field.Signature
                            };

                            sourceRecord.OutgoingReferences.Add(edge);
                        }
                    }
                }
            }
        }

        public void BuildGraph(IEnumerable<Record> allRecords) => BuildGraph(allRecords, null);

        private bool IsPotentialReferenceField(string signature, byte[] rawData, string parentRecordSignature)
        {
            if (rawData == null || rawData.Length < 4) return false;

            string sig = signature.ToUpperInvariant();

            if (sig == "NAME" || sig == "CNAM" || sig == "PNAM" || sig == "QNAM" || sig == "TNAM" ||
                sig == "INAM" || sig == "RNAM" || sig == "YNAM" || sig == "ANAM" || sig == "SNAM" ||
                sig == "FNAM" || sig == "LNAM" || sig == "MNAM" || sig == "ONAM" || sig == "XNAM")
            {
                return true;
            }

            if (sig == "DATA" && (parentRecordSignature == "REFR" || parentRecordSignature == "ACHR" || parentRecordSignature == "PGRE"))
            {
                return true;
            }

            if (sig == "CNTO" || sig == "LVLO")
            {
                return true;
            }

            return false;
        }
    }
}

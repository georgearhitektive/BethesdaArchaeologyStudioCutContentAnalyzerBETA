﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
using BethesdaArchaeologyStudio.Core.Models;

namespace BethesdaArchaeologyStudio.Database.Database
{
    public class DiffEngine
    {
        public class FindingPackage
        {
            public string Name { get; set; } = string.Empty;
            public List<Finding> Findings { get; set; } = new List<Finding>();
        }

        private string GetFindingUniqueKey(Finding f)
        {
            if (f?.TargetRecord == null) return Guid.NewGuid().ToString();

            // SmartFormId-t közvetlenül használjuk a kulcsban, nem kell konvertálni
            return $"{f.Category}_{f.Title}_{f.TargetRecord.FormId}";
        }

        public void GenerateMultiFindingDiffHtml(
            FindingPackage basePackage,
            List<FindingPackage> compPackages,
            string outputPath,
            bool includeNew,
            bool includeModified,
            bool includeDeleted)
        {
            var baseLookup = basePackage.Findings
                                 .GroupBy(GetFindingUniqueKey)
                                 .ToDictionary(g => g.Key, g => g.First());

            using var writer = new StreamWriter(outputPath, false, Encoding.UTF8);
            writer.WriteLine("<!DOCTYPE html><html><body><h1>Riport</h1>");

            foreach (var compPackage in compPackages)
            {
                writer.WriteLine($"<h2>{compPackage.Name}</h2><table>");
                foreach (var f in compPackage.Findings)
                {
                    string key = GetFindingUniqueKey(f);
                    bool isNew = !baseLookup.ContainsKey(key);

                    if (isNew && includeNew)
                        writer.WriteLine($"<tr><td>{f.Title}</td><td>New</td></tr>");
                }
                writer.WriteLine("</table>");
            }
            writer.WriteLine("</body></html>");
        }
    }
}
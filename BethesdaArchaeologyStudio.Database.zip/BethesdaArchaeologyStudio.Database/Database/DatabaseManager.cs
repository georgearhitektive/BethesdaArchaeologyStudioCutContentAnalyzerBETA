﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Data.Sqlite;
using BethesdaArchaeologyStudio.Core.Models;

namespace BethesdaArchaeologyStudio.Database.Database
{
    public class DatabaseManager
    {
        private readonly string _connectionString;
        public DatabaseManager(string dbFileName = "ArchaeologyStudio.db")
        {
            _connectionString = $"Data Source={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, dbFileName)};";
            InitializeDatabase();
        }

        private void InitializeDatabase()
        {
            using var conn = new SqliteConnection(_connectionString);
            conn.Open();
            // JAVÍTVA: Az adatbázis táblában az oszlop neve "SmartFormId" lett, hogy egységes legyen a mentéssel és a modellel
            using var cmd = new SqliteCommand(@"
                CREATE TABLE IF NOT EXISTS Plugins (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT, 
                    FileName TEXT NOT NULL UNIQUE, 
                    ImportDate TEXT
                );
                CREATE TABLE IF NOT EXISTS Records (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT, 
                    PluginId INTEGER, 
                    SmartFormId TEXT, 
                    Signature TEXT, 
                    Flags INTEGER, 
                    FOREIGN KEY(PluginId) REFERENCES Plugins(Id)
                );", conn);
            cmd.ExecuteNonQuery();
        }

        public void ClearDatabase()
        {
            using var conn = new SqliteConnection(_connectionString);
            conn.Open();
            using var cmd = new SqliteCommand("DELETE FROM Records; DELETE FROM Plugins; VACUUM;", conn);
            cmd.ExecuteNonQuery();
        }

        public void SaveRecords(string fileName, List<Record> records)
        {
            using var conn = new SqliteConnection(_connectionString);
            conn.Open();
            using var transaction = conn.BeginTransaction();

            long pluginId;
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandText = "INSERT INTO Plugins (FileName, ImportDate) VALUES (@name, @date); SELECT last_insert_rowid();";
                cmd.Parameters.AddWithValue("@name", fileName);
                cmd.Parameters.AddWithValue("@date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                var scalar = cmd.ExecuteScalar();
                if (scalar == null || scalar == DBNull.Value)
                    throw new InvalidOperationException("Failed to insert plugin and retrieve id.");

                pluginId = scalar is long l ? l : Convert.ToInt64(scalar);
            }

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = transaction;
                // JAVÍTVA: Biztosítva, hogy a beszúrás a létrehozott "SmartFormId" oszlopba történjen
                cmd.CommandText = "INSERT INTO Records (PluginId, SmartFormId, Signature, Flags) VALUES (@pid, @fid, @sig, @flg);";
                cmd.Parameters.AddWithValue("@pid", pluginId);

                // Előre létrehozzuk a paramétereket a ciklus előtt a jobb teljesítmény érdekében
                var fidParam = cmd.Parameters.Add("@fid", SqliteType.Text);
                var sigParam = cmd.Parameters.Add("@sig", SqliteType.Text);
                var flgParam = cmd.Parameters.Add("@flg", SqliteType.Integer);

                foreach (var r in records)
                {
                    // JAVÍTVA: Biztonságos ToString() hívás a SmartFormId objektumon
                    fidParam.Value = r.FormId.ToString() ?? "00000000";
                    sigParam.Value = r.Signature ?? "UNKN";
                    flgParam.Value = (long)r.Flags;
                    cmd.ExecuteNonQuery();
                }
            }

            transaction.Commit();
        }
    }
}

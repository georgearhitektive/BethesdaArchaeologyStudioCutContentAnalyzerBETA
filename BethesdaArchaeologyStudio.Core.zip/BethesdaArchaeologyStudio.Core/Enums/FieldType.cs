﻿using System;
using System.Collections.Generic;

namespace BethesdaArchaeologyStudio.Core.Enums
{

    public enum FieldType
    {

        Unknown,


        // Strings
        String,
        LocalizedString,

        DLSTRING,
        ILSTRING,
        STRING,


        // Numbers
        Integer,
        Float,


        // Bethesda references
        FormId,
        Reference,


        // Data
        Binary,
        RawBytes,


        // Compression
        CompressedZlib,
        CompressedZstd

    }

}
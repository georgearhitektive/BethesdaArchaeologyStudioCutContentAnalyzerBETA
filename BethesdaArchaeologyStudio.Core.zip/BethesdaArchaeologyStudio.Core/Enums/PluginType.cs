﻿// Enums/PluginType.cs
namespace BethesdaArchaeologyStudio.Core.Enums
{
    public enum PluginType
    {
        ESM, // Master file
        ESP, // Plugin file
        ESL  // Light master file (Skyrim SE / Fallout 4 óta)
    }
}
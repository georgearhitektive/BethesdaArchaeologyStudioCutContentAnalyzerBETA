﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BethesdaArchaeologyStudio.Core.Enums
{
    public enum BethesdaGameType
    {
        Unknown,

        Skyrim,
        SkyrimSE,
        SkyrimLE,
        Oblivion,

        Fallout3,
        Fallout4,
        Fallout76,

        Starfield,
        OblivionRemastered,
    }
}

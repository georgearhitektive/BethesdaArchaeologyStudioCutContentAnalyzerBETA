﻿// Enums/FindingSeverity.cs
namespace BethesdaArchaeologyStudio.Core.Enums
{
    public enum FindingSeverity
    {
        Info,
        Warning,
        Error,
        Critical
    }
}
﻿using System.Collections.Generic;
using BethesdaArchaeologyStudio.Core.Models;

namespace BethesdaArchaeologyStudio.Core.Interfaces
{
    public interface IAnalyzer
    {
        string Name { get; }
        string Description { get; }
        // Átírtuk List<Finding>-ról IEnumerable<Finding>-ra, hogy egyezzen az osztályokkal!
        IEnumerable<Finding> Analyze(IEnumerable<Record> database);
    }
}
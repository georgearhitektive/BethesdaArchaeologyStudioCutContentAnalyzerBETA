﻿using System;

namespace BethesdaArchaeologyStudio.Core.Models
{
    public class Finding
    {
        public string AnalyzerName { get; set; } = string.Empty;
        public Record TargetRecord { get; set; } = new Record();

        public string Title { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;

        public int ScriptCount { get; set; }
        public int ConditionCount { get; set; }
        public int AliasCount { get; set; }

        public int RelatedNpcCount { get; set; }
        public int RelatedDialogueCount { get; set; }
        public int RelatedSceneCount { get; set; }
        public int RelatedVoiceCount { get; set; }

        public string UsageSummary { get; set; } = string.Empty;
        public double Confidence { get; set; }
        public string DialogContent { get; set; } = string.Empty;
    }
}
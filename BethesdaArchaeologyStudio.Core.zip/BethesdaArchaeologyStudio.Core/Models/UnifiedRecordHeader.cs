﻿namespace BethesdaArchaeologyStudio.Core.Models
{
    public struct UnifiedRecordHeader
    {
        public string Signature { get; set; }

        public uint DataSize { get; set; }

        public uint Flags { get; set; }

        public uint SmartFormId { get; set; }

        public uint VersionControl { get; set; }

        public uint Unknown { get; set; }

        public bool IsCompressed =>
            (Flags & 0x00040000) != 0;
    }


    public struct UnifiedSubRecordHeader
    {
        public string Signature { get; set; }

        public uint DataSize { get; set; }

        public bool IsExtended =>
            Signature == "XXXX";
    }
}
﻿using System;

namespace BethesdaArchaeologyStudio.Core.Models
{
    public class Reference
    {
        public SmartFormId Source { get; set; }
        public SmartFormId Target { get; set; }
        public string Context { get; set; } = string.Empty;
    }
}
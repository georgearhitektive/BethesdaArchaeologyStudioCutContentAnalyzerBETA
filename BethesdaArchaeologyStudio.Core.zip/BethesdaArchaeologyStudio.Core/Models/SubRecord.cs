﻿using System;
using System.Text;

namespace BethesdaArchaeologyStudio.Core.Models
{
    public class Subrecord
    {
        public string Signature { get; set; } = string.Empty;

        // JAVÍTÁS: ushort-ról uint-re módosítva a Starfield nagyméretű (65535 bájtnál nagyobb) subrecordjai miatt!
        public uint DataSize { get; set; }

        // Memória-hatékony nézet a fő pufferre
        public ReadOnlyMemory<byte> Data { get; set; }

        // Segédmetódus az egyszerű kiolvasáshoz
        public string GetString(Encoding encoding) =>
            encoding.GetString(Data.Span).TrimEnd('\0');
    }
}

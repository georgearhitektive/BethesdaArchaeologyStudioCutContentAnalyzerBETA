﻿using System;
using BethesdaArchaeologyStudio.Core.Enums;

namespace BethesdaArchaeologyStudio.Core.Models
{
    public class Field
    {
        public string Signature { get; set; } = string.Empty;
        public FieldType Type { get; set; }
        public byte[] RawData { get; set; } = Array.Empty<byte>();
        public string Value { get; set; } = string.Empty;
        public string FunctionName { get; set; } = string.Empty;

        // Az analizátor által elvárt extra tulajdonságok
        public SmartComparisonOperator ComparisonOperator { get; set; }
        public SmartComparisonOperator ComparisonValue { get; set; }
    }

    public struct SmartComparisonOperator : IEquatable<SmartComparisonOperator>
    {
        private int _value;
        private string _strValue;

        public SmartComparisonOperator(int val)
        {
            _value = val;
            _strValue = val.ToString();
        }

        public static implicit operator int(SmartComparisonOperator op) => op._value;
        public bool Equals(SmartComparisonOperator other)
        {
            return _value == other._value;
        }

        public override bool Equals(object? obj)
        {
            return obj is SmartComparisonOperator other && Equals(other);
        }

        public override int GetHashCode()
        {
            return _value.GetHashCode();
        }

        public override string ToString()
        {
            return _strValue ?? _value.ToString();
        }

        public static bool operator ==(SmartComparisonOperator left, SmartComparisonOperator right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(SmartComparisonOperator left, SmartComparisonOperator right)
        {
            return !left.Equals(right);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace BethesdaArchaeologyStudio.Core.Models
{
    // JAVÍTVA: IEquatable implementáció a villámgyors szótár- és halmaz-keresésekhez
    public struct SmartFormId : IEquatable<SmartFormId>
    {
        public uint Value { get; }
        public SmartFormId(uint value) => Value = value;

        // Gyors, boxing-mentes egyenlőségvizsgálat
        public bool Equals(SmartFormId other) => Value == other.Value;

        public override bool Equals(object? obj) => obj is SmartFormId other && Equals(other);

        // A belső uint Hash kódja tökéletesen egyedi és gyors
        public override int GetHashCode() => Value.GetHashCode();

        // Kényelmi operátorok a kód többi részéhez
        public static bool operator ==(SmartFormId left, SmartFormId right) => left.Equals(right);
        public static bool operator !=(SmartFormId left, SmartFormId right) => !left.Equals(right);

        public override string ToString() => $"0x{Value:X8}";
        public static implicit operator SmartFormId(uint value) => new SmartFormId(value);
    }

    // A te eredeti, tökéletes Record osztályod
    public class Record
    {
        // Alapvető azonosítók
        public string Signature { get; set; } = string.Empty;

        public SmartFormId FormId { get; set; }

        public string EditorId { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public ulong Flags { get; set; }
        public string RawDetailsDump { get; set; } = string.Empty;

        public Plugin? ParentPlugin { get; set; }

        public bool IsGroup { get; set; }

        // Tömörítési metaadatok
        public bool IsCompressed { get; set; }
        public bool IsDelta { get; set; }

        public byte[] RawData { get; set; } = Array.Empty<byte>();

        public List<Record> Children { get; set; } = new List<Record>();
        public List<Field> Fields { get; set; } = new List<Field>();
        public List<Reference> OutgoingReferences { get; set; } = new List<Reference>();
        public List<Field> Conditions { get; set; } = new List<Field>();

        public bool IsDeleted => (Flags & 0x20) != 0;

        public uint DataSize { get; set; }

        // --- ALAP STATISZTIKÁK ---
        public float Weight { get; set; }
        public uint Value { get; set; }

        // --- ÚJ MEZŐK: FEGYVER ÉS PÁNCÉL EXTRÁK ---
        public ushort? Damage { get; set; }
        public string? AmmoId { get; set; }
        public string? EnchantmentId { get; set; }

        public string DevelopmentNotes { get; set; } = string.Empty;

        public string FormattedDevNote
        {
            get
            {
                // 1. Általános törlés ellenőrzés (minden típusra)
                if (IsDeleted)
                {
                    return Signature switch
                    {
                        "DIAL" or "INFO" => "Deleted dialogue",
                        _ => "Deleted item"
                    };
                }

                // 2. Ha nincs törölve, akkor a típus (Signature) alapján döntünk
                return Signature switch
                {
                    "CELL" => IsDeleted ? "Inaccessible cell" : "Available cell",
                    "DIAL" or "INFO" => "Modified dialogue",
                    "ARMO" or "WEAP" or "BOOK" => "Scripted element",
                    "QUST" => IsDeleted ? "Deleted Quest" : "Available Quest",
                    "NPC_" => IsDeleted ? "Deleted NPC" : "Available NPC",
                    // Ha egyik sem, akkor visszatérünk az eredeti DevelopmentNotes szöveggel (ha van)
                    _ => !string.IsNullOrEmpty(DevelopmentNotes) ? DevelopmentNotes : "No extra information"
                };
            }
        }

        public string OriginalPluginName
        {
            get
            {
                return ParentPlugin?.Name ?? string.Empty;
            }
        }

        public string DialogueStringId { get; set; } = string.Empty;

        public string VoiceId { get; set; } = string.Empty;

        public int NpcCount { get; set; }
        public string CompletionStatus { get; set; } = string.Empty;

        public uint? RawAmmoFormId { get; set; }
        public uint? RawEnchantmentFormId { get; set; }

        
    }
}
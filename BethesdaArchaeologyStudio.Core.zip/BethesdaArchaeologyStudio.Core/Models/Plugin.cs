﻿using System;
using System.Collections.Generic;
using BethesdaArchaeologyStudio.Core.Enums; // Ez hivatkozik a már létező enumra

namespace BethesdaArchaeologyStudio.Core.Models
{
    public class Plugin
    {
        public string Name { get; set; } = string.Empty;

        public string Author { get; set; } = string.Empty;

        public PluginType Type { get; set; }


        // Load order pozíció
        public int LoadOrderIndex { get; set; }


        // ESL flag
        public bool IsLightPlugin { get; set; }


        // Master plugin?
        public bool IsMaster { get; set; }


        public List<string> Masters { get; set; }
            = new List<string>();


        public List<Record> Records { get; set; }
            = new List<Record>();
    }
}
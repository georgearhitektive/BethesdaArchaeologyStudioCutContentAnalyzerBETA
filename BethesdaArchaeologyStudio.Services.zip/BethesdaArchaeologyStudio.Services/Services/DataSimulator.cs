﻿using System;
using System.Collections.Generic;
using BethesdaArchaeologyStudio.Core.Models;
namespace BethesdaArchaeologyStudio.Services.Services
{
    public static class DataSimulator
    {
        public static List<Record> GenerateMockGameDatabase()
        {
            var records = new List<Record>();

            // 1. Fegyverek, Páncélok, NPC-k (Phase 2 alapok)
            // Az implicit konverzió helyett használjuk az explicit konstruktort a CS0029 elkerülésére
            records.Add(new Record
            {
                Signature = "WEAP",
                FormId = new SmartFormId(0x080013984),
                EditorId = "DunTestSword",
                FullName = "Fejlesztői Teszt Kard"
            });

            records.Add(new Record
            {
                Signature = "ARMO",
                FormId = new SmartFormId(0x0800139A8),
                EditorId = "ArmorTestCut",
                FullName = "Kivágott Ébenfa Páncél"
            });

            records.Add(new Record
            {
                Signature = "NPC_",
                FormId = new SmartFormId(0x08002C923),
                EditorId = "CutNpcMinor",
                FullName = "Elfeledett Bányász"
            });

            // 2. Cellák (Phase 1)
            records.Add(new Record
            {
                Signature = "CELL",
                FormId = new SmartFormId(0x08008A31F),
                EditorId = "UnusedTestRoom",
                FullName = "Fejlesztői Teszt Kamra"
            });

            return records;
        }
    }
}
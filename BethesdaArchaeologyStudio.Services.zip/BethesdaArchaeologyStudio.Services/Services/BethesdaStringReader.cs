﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Buffers;
using System.Buffers.Binary;
using BethesdaArchaeologyStudio.Core.Enums;

namespace BethesdaArchaeologyStudio.Parser.Parser
{
    public sealed class BethesdaStringReader : IDisposable
    {
        private readonly Dictionary<uint, string> _strings = new Dictionary<uint, string>();
        private readonly Dictionary<uint, string> _dlStrings = new Dictionary<uint, string>();
        private readonly Dictionary<uint, string> _ilStrings = new Dictionary<uint, string>();
        public IEnumerable<KeyValuePair<uint, string>> GetAllStrings() => _strings;
        public IEnumerable<KeyValuePair<uint, string>> GetAllDlStrings() => _dlStrings;
        public IEnumerable<KeyValuePair<uint, string>> GetAllIlStrings() => _ilStrings;

        private bool _isDisposed;

        public void OpenPlugin(string pluginFilePath, BethesdaGameType gameType)
        {
            ThrowIfDisposed();
            LoadSmart(pluginFilePath, gameType);
        }

        public void ClearAll()
        {
            _strings.Clear();
            _dlStrings.Clear();
            _ilStrings.Clear();
        }

        public void LoadSmart(string pluginPath, BethesdaGameType gameType)
        {
            ThrowIfDisposed();

            string directory = Path.GetDirectoryName(pluginPath) ?? string.Empty;
            if (string.IsNullOrEmpty(directory) || !Directory.Exists(directory)) return;

            string baseName = Path.GetFileNameWithoutExtension(pluginPath);
            if (string.IsNullOrEmpty(baseName)) return;
            var files = Directory.GetFiles(directory, $"{baseName}*.*");

            foreach (var file in files)
            {
                string ext = Path.GetExtension(file).ToLowerInvariant();
                if (ext == ".strings" || ext == ".dlstrings" || ext == ".ilstrings")
                {
                    if (new FileInfo(file).Length > 1000)
                    {
                        Load(file, gameType);
                    }
                }
            }
        }

        public void Load(string filePath, BethesdaGameType gameType)
        {
            ThrowIfDisposed();
            if (!File.Exists(filePath)) return;

            System.Diagnostics.Debug.WriteLine($"[DEBUG] Loading in progress: {Path.GetFileName(filePath)} - Current dictionary size: {_strings.Count + _dlStrings.Count + _ilStrings.Count}");

            string extension = Path.GetExtension(filePath).ToLowerInvariant();
            Dictionary<uint, string> targetDict = extension switch
            {
                ".dlstrings" => _dlStrings,
                ".ilstrings" => _ilStrings,
                _ => _strings
            };

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            Encoding encoding = gameType switch
            {
                BethesdaGameType.Fallout3 => Encoding.GetEncoding(1252),
                BethesdaGameType.SkyrimLE => Encoding.GetEncoding(1252),
                BethesdaGameType.Starfield => Encoding.UTF8,
                BethesdaGameType.Fallout4 => Encoding.UTF8,
                BethesdaGameType.SkyrimSE => Encoding.UTF8,
                _ => Encoding.UTF8
            };

            using var fs = File.OpenRead(filePath);
            if (fs.Length < 8) return;

            Span<byte> headerBuffer = stackalloc byte[8];
            fs.ReadExactly(headerBuffer);

            uint stringCount = BinaryPrimitives.ReadUInt32LittleEndian(headerBuffer.Slice(0, 4));
            uint dataSize = BinaryPrimitives.ReadUInt32LittleEndian(headerBuffer.Slice(4, 4));

            if (dataSize > 500 * 1024 * 1024) return;

            int totalTableSize = (int)(stringCount * 8);
            byte[] tableBuffer = ArrayPool<byte>.Shared.Rent(totalTableSize);
            byte[] dataBuffer = ArrayPool<byte>.Shared.Rent((int)dataSize);

            try
            {
                fs.ReadExactly(tableBuffer.AsSpan(0, totalTableSize));
                fs.ReadExactly(dataBuffer.AsSpan(0, (int)dataSize));

                for (int i = 0; i < stringCount; i++)
                {
                    int pos = i * 8;
                    if (pos + 8 > totalTableSize) break;

                    uint id = BinaryPrimitives.ReadUInt32LittleEndian(tableBuffer.AsSpan(pos, 4));
                    uint offset = BinaryPrimitives.ReadUInt32LittleEndian(tableBuffer.AsSpan(pos + 4, 4));

                    if (offset >= dataSize) continue;

                    // --- JAVÍTOTT RÉSZ: ELÁGAZÁS FÁJLTÍPUS SZERINT ---
                    if (extension == ".dlstrings" || extension == ".ilstrings")
                    {
                        // dlstrings / ilstrings struktúra: [4 bájt hossz] + [szöveg]
                        if (offset + 4 <= dataSize)
                        {
                            uint textLength = BinaryPrimitives.ReadUInt32LittleEndian(dataBuffer.AsSpan((int)offset, 4));

                            // Biztonsági ellenőrzés, hogy ne olvassunk túl a fájlon
                            if (textLength > 0 && offset + 4 + textLength <= dataSize)
                            {
                                // A szöveget az offset + 4 -től olvassuk, pontosan textLength hosszan!
                                targetDict[id] = encoding.GetString(dataBuffer, (int)offset + 4, (int)textLength);
                            }
                            else
                            {
                                targetDict[id] = string.Empty;
                            }
                        }
                    }
                    else
                    {
                        // sima .strings struktúra: [szöveg] + [NULL terminátor]
                        int length = 0;
                        if (encoding == Encoding.Unicode)
                        {
                            while (offset + length + 1 < dataSize &&
                                  (dataBuffer[offset + length] != 0 || dataBuffer[offset + length + 1] != 0))
                            {
                                length += 2;
                                if (length > 10000) break;
                            }
                        }
                        else
                        {
                            while (offset + length < dataSize && dataBuffer[offset + length] != 0)
                            {
                                length++;
                                if (length > 10000) break;
                            }
                        }

                        targetDict[id] = length > 0 ? encoding.GetString(dataBuffer, (int)offset, length) : string.Empty;
                    }
                    // -------------------------------------------------
                }
            }
            finally
            {
                ArrayPool<byte>.Shared.Return(tableBuffer);
                ArrayPool<byte>.Shared.Return(dataBuffer);
            }
        }

        public string? GetString(uint id) => _strings.TryGetValue(id, out var text) ? text : null;
        public string? GetDlString(uint id) => _dlStrings.TryGetValue(id, out var text) ? text : GetString(id);
        public string? GetIlString(uint id) => _ilStrings.TryGetValue(id, out var text) ? text : GetString(id);

        private void ThrowIfDisposed() => ObjectDisposedException.ThrowIf(_isDisposed, this);
        public void Dispose()
        {
            _strings.Clear();
            _dlStrings.Clear();
            _ilStrings.Clear();
            _isDisposed = true;
        }

        public void LoadBaseGameStrings(string dataFolderPath, BethesdaGameType gameType)
        {
            string stringsPath = Path.Combine(dataFolderPath, "Strings");

            if (!Directory.Exists(stringsPath))
            {
                System.Diagnostics.Debug.WriteLine($"[HIBA] The Strings folder cannot be found: {stringsPath}");
                return;
            }

            string[] baseFiles = { "Starfield_en.strings", "Starfield_en.dlstrings", "Starfield_en.ilstrings" };

            foreach (var fileName in baseFiles)
            {
                string filePath = Path.Combine(stringsPath, fileName);
                if (File.Exists(filePath))
                {
                    Load(filePath, gameType);
                }
            }
        }
    }
}
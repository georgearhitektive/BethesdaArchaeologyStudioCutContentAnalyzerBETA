﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Data.Sqlite;
using BethesdaArchaeologyStudio.Core.Models;
using BethesdaArchaeologyStudio.Export;

namespace BethesdaArchaeologyStudio.Services
{
    public class ReportService
    {
        private readonly string _connectionString = "Data Source=ArchaeologyStudio.db";

        /// <summary>
        /// JAVÍTVA: Közvetlenül a memóriában lévő, részletes Findings listából generál jelentést (Ajánlott módszer)
        /// </summary>
        public void ExportListToHtml(IEnumerable<Finding> findings, string pluginName, string outputPath)
        {
            string html = HtmlReportExporter.ExportToHtml(findings, pluginName);
            File.WriteAllText(outputPath, html, Encoding.UTF8); // JAVÍTVA: Fix UTF8 kódolás a magyar karakterekért
        }

        /// <summary>
        /// Generál egy HTML riportot az adatbázisban tárolt Cut Content találatokból (Javított tartalék verzió)
        /// </summary>
        public void ExportDatabaseToHtml(string pluginName, string outputPath)
        {
            var findings = FetchFindingsFromDb(pluginName);
            string html = HtmlReportExporter.ExportToHtml(findings, pluginName);
            File.WriteAllText(outputPath, html, Encoding.UTF8);
        }

        private List<Finding> FetchFindingsFromDb(string pluginName)
        {
            var findings = new List<Finding>();

            using var conn = new SqliteConnection(_connectionString);
            conn.Open();

            // JAVÍTVA: Beolvassuk a RawDetailsDump-ot is az adatbázisból, ha az el lett mentve, 
            // és kivettük a szigorú 0x20-as SQL szűrést, hogy a kulcsszavas találatok is meglegyenek!
            string sql = @"
                SELECT r.SmartFormId, r.Signature, r.EditorId, r.FullName, r.RawDetailsDump, r.Flags 
                FROM Records r
                JOIN Plugins p ON r.PluginId = p.Id
                WHERE p.FileName = @pluginName;";

            using var cmd = new SqliteCommand(sql, conn);
            cmd.Parameters.AddWithValue("@pluginName", pluginName);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string rawSmartFormId = reader.GetString(0);
                uint val = Convert.ToUInt32(rawSmartFormId.Replace("0x", ""), 16);

                string signature = reader.GetString(1);
                string editorId = reader.IsDBNull(2) ? "" : reader.GetString(2);
                string fullName = reader.IsDBNull(3) ? "" : reader.GetString(3);
                string detailsDump = reader.IsDBNull(4) ? "" : reader.GetString(4);
                long flags = reader.IsDBNull(5) ? 0 : reader.GetInt64(5);

                bool isDeleted = (flags & 0x20) != 0;

                // Csak azokat a rekordokat rekonstruáljuk leletként, amik valóban Cut Content gyanúsak
                // (Ez szinkronban van az ArchaeologyEngine logikájával)
                bool hasCutKeyword = !string.IsNullOrEmpty(editorId) &&
                    (editorId.Contains("CUT", StringComparison.OrdinalIgnoreCase) ||
                     editorId.Contains("UNUSED", StringComparison.OrdinalIgnoreCase) ||
                     editorId.Contains("TEST", StringComparison.OrdinalIgnoreCase));

                if (isDeleted || hasCutKeyword)
                {
                    var record = new Record
                    {
                        FormId = new SmartFormId(val),
                        Signature = signature,
                        EditorId = editorId,
                        FullName = fullName,
                        RawDetailsDump = detailsDump,
                        Flags = (ulong)flags
                    };

                    findings.Add(new Finding
                    {
                        Title = $"{signature}: {(string.IsNullOrEmpty(editorId) ? "[No EditorID]" : editorId)}",
                        Category = isDeleted ? "Deleted Record" : "Unused / Dev Residual",
                        // JAVÍTVA: Összefűzzük a leírást a kinyert belső statisztikákkal, hogy a HTML-ben is megjelenjenek
                        Description = $"Fájl: {pluginName}, ID: {record.FormId}, Név: {(string.IsNullOrEmpty(fullName) ? "-" : fullName)}\n\n{detailsDump}",
                        Confidence = isDeleted ? 0.95 : 0.85,
                        TargetRecord = record
                    });
                }
            }
            return findings;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using BethesdaArchaeologyStudio.Core.Models;
using BethesdaArchaeologyStudio.Core.Interfaces;
using BethesdaArchaeologyStudio.Analysis.Analysis;
using BethesdaArchaeologyStudio.Analysis;
using BethesdaArchaeologyStudio.Core.Services;


namespace BethesdaArchaeologyStudio.Services
{
    public class ArchaeologyEngine
    {
        public List<IAnalyzer> Analyzers { get; set; }

        public ArchaeologyEngine()
        {
            // Elemzők betöltése az Analysis mappából
            Analyzers = new List<IAnalyzer>
            {
                new CutDialogueAnalyzer(),
                new DeletedCellAnalyzer(),
                new UnreachableConditionAnalyzer(),
                new UnusedAssetAnalyzer(),
                new UnusedQuestAnalyzer()
            };
        }

        public List<Finding> RunMultiPluginAnalysis(Dictionary<string, List<Record>> loadOrderDatabase, string loadedPluginName)
        {
            var allFindings = new List<Finding>();
            var flatRecordList = new List<Record>();

            Debug.WriteLine($"[ENGINE] Starting modular analysis. Plugin: {loadedPluginName}");
            int totalReceived = loadOrderDatabase.Values.Sum(list => list.Count);
            Debug.WriteLine($"[ENGINE] Received {totalReceived} root records/groups from the parser.");

            // 1. LÉPÉS: Fa szerkezet kilapítása és memória-optimalizálás
            foreach (var pluginEntry in loadOrderDatabase)
            {
                string sourcePlugin = pluginEntry.Key;
                foreach (var record in pluginEntry.Value)
                {
                    FlattenRecordTree(record, sourcePlugin, flatRecordList);
                }
            }

            Debug.WriteLine($"[ENGINE] Flattened down to {flatRecordList.Count} analyzable records. (String/text data preserved).");

            if (flatRecordList.Count == 0) return allFindings;

            // 2. LÉPÉS: Specifikus Analyzerek futtatása
            foreach (var analyzer in Analyzers)
            {
                try
                {
                    Debug.WriteLine($"[ENGINE] Running {analyzer.Name}...");
                    var results = analyzer.Analyze(flatRecordList);

                    if (results != null && results.Any())
                    {
                        var findingList = results.ToList();
                        foreach (var finding in findingList)
                        {
                            if (string.IsNullOrEmpty(finding.AnalyzerName))
                            {
                                finding.AnalyzerName = analyzer.Name;
                            }
                        }

                        allFindings.AddRange(findingList);
                        Debug.WriteLine($"[ENGINE] -> {analyzer.Name} found {findingList.Count} items.");
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[ENGINE] ERROR in {analyzer.Name}: {ex.Message}");
                }
            }

            // 3. LÉPÉS: Memória felszabadítása
            flatRecordList.Clear();
            flatRecordList = null;

            Debug.WriteLine($"[ENGINE] Analysis complete. Total findings: {allFindings.Count}");
            return allFindings;
        }

        // --- SEGÉDFÜGGVÉNY: FA KILAPÍTÁSA ---
        private void FlattenRecordTree(Record record, string sourcePlugin, List<Record> flatList)
        {
            if (record == null) return;

            if (record.IsGroup)
            {
                if (record.Children != null)
                {
                    foreach (var child in record.Children)
                    {
                        FlattenRecordTree(child, sourcePlugin, flatList);
                    }
                }
                return;
            }

            // A memóriazabáló rekordok eldobása (LAND, NAVM), de minden más (szövegek, dialógusok, stb.) megmarad
            if (record.Signature == "LAND" || record.Signature == "NAVM")
            {
                return;
            }

            flatList.Add(record);

            if (record.Children != null)
            {
                foreach (var child in record.Children)
                {
                    FlattenRecordTree(child, sourcePlugin, flatList);
                }
            }
        }
    }
}
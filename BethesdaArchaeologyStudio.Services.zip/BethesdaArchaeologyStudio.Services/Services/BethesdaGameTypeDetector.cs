﻿using System;
using System.IO;
using BethesdaArchaeologyStudio.Core.Enums;

namespace BethesdaArchaeologyStudio.Parser.Parser
{
    public static class BethesdaGameTypeDetector
    {
        public static BethesdaGameType Detect(string filePath)
        {
            if (string.IsNullOrEmpty(filePath)) return BethesdaGameType.Unknown;

            // A teljes elérési utat is vizsgáljuk, kisbetűsítve a könnyebb keresésért
            string fullPath = filePath.ToLower();
            string fileName = Path.GetFileName(filePath).ToLower();

            // Oblivion Remastered
            if (fileName.Contains("OblivionRemastered") || fullPath.Contains("Oblivion Remastered"))
                return BethesdaGameType.OblivionRemastered;

            // Starfield
            if (fileName.Contains("starfield") || fileName.StartsWith("sf") || fullPath.Contains("starfield"))
                return BethesdaGameType.Starfield;

            // Fallout 4
            if (fileName.Contains("fallout4") || fileName.StartsWith("fo4") || fullPath.Contains("fallout 4"))
                return BethesdaGameType.Fallout4;

            // Oblivion Remastered
            if (fileName.Contains("Oblivion") || fullPath.Contains("Oblivion"))
                return BethesdaGameType.Oblivion;

            // Fallout 76
            if (fileName.Contains("fallout76") || fileName.Contains("seventysix") || fullPath.Contains("fallout76"))
                return BethesdaGameType.Fallout76;

            // Skyrim Special Edition / Anniversary Edition
            if (fileName.Contains("skyrimse") || fullPath.Contains("skyrim special edition"))
                return BethesdaGameType.SkyrimSE; // JAVÍTVA: Megfelel a ModGenerator Enum-jának!

            // Skyrim Legendary Edition (sima Skyrim)
            if (fileName == "skyrim.esm" || fileName == "update.esm" || fullPath.Contains("skyrim"))
                return BethesdaGameType.SkyrimLE; // JAVÍTVA: Megfelel a ModGenerator Enum-jának!

            return BethesdaGameType.Unknown;
        }
    }
}
﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text.Json; // Ezt hozzáadtuk a JSON szerializációhoz
using BethesdaArchaeologyStudio.Core.Models;

namespace BethesdaArchaeologyStudio.Export
{
    public class HtmlReportExporter
    {
        public static string ExportToHtml(IEnumerable<Finding> findings, string pluginName)
        {
            var sb = new StringBuilder();

            // HTML Fejléc és stílusok
            sb.AppendLine("<!DOCTYPE html>");
            sb.AppendLine("<html>");
            sb.AppendLine("<head>");
            sb.AppendLine("    <meta charset='utf-8'>");
            sb.AppendLine($"    <title>Archaeological Report - {pluginName}</title>");
            sb.AppendLine("    <style>");
            sb.AppendLine("        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #1e1e24; color: #e0e0e0; padding: 20px; margin: 0; }");
            sb.AppendLine("        .container { max-width: 1000px; margin: 40px auto; }");
            sb.AppendLine("        h1 { color: #007ACC; border-bottom: 2px solid #007ACC; padding-bottom: 10px; margin-bottom: 5px; font-size: 2.2em; }");
            sb.AppendLine("        .meta { color: #888; font-size: 0.9em; margin-bottom: 30px; }");

            // Kártya stílusok
            sb.AppendLine("        .card { background: #252526; border-left: 5px solid #007ACC; padding: 20px; margin-bottom: 20px; border-radius: 4px; box-shadow: 0 4px 10px rgba(0,0,0,0.4); border: 1px solid #333; border-left-width: 5px; }");
            sb.AppendLine("        .card.deleted { border-left-color: #ff4d4d; }");
            sb.AppendLine("        .card.residual { border-left-color: #ff9f1c; }");
            sb.AppendLine("        .card-title { font-size: 1.25em; font-weight: bold; color: #ffffff; display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }");
            sb.AppendLine("        .card-meta { font-size: 0.85em; color: #aaa; margin-bottom: 15px; border-bottom: 1px solid #3a3a3a; padding-bottom: 10px; }");

            // Jelvény és adat stílusok (ugyanaz maradt)
            sb.AppendLine("        .badge { color: white; padding: 4px 10px; border-radius: 3px; font-size: 0.75em; font-weight: bold; text-transform: uppercase; letter-spacing: 0.5px; }");
            sb.AppendLine("        .badge.deleted-tag { background: #ff4d4d; }");
            sb.AppendLine("        .badge.residual-tag { background: #ff9f1c; }");
            sb.AppendLine("        .badge.high-tag { background: #007ACC; }");
            sb.AppendLine("        .badge-type { padding: 3px 8px; border-radius: 3px; font-size: 0.8em; font-weight: bold; color: #fff; display: inline-block; margin-bottom: 8px; }");
            sb.AppendLine("        .b-weap { background: #d90429; } .b-armo { background: #4a90e2; } .b-npc  { background: #9b5de5; }");
            sb.AppendLine("        .b-cell { background: #00bbf9; } .b-dial { background: #00f5d4; color: #1e1e24; } .b-generic { background: #6c757d; }");

            sb.AppendLine("        .evidence { background: #111114; padding: 15px; margin-top: 15px; border-radius: 4px; font-family: 'Consolas', monospace; color: #E0E0E0; border: 1px solid #3F3F46; line-height: 1.6; }");
            sb.AppendLine("        .dev-note { color: #00CCFF; font-weight: bold; font-family: 'Segoe UI', sans-serif; margin-top: 10px; margin-bottom: 5px; font-size: 0.9em; }");
            sb.AppendLine("        .stat-basic { color: #AAAAAA; font-size: 0.9em; margin-bottom: 3px; }");
            sb.AppendLine("        .stat-damage { color: #FF6666; font-weight: bold; font-size: 0.9em; margin-bottom: 3px; }");
            sb.AppendLine("        .stat-ammo { color: #DDDDDD; font-size: 0.9em; margin-bottom: 3px; }");
            sb.AppendLine("        .stat-enchant { color: #CC66FF; font-weight: bold; font-size: 0.9em; margin-bottom: 3px; }");
            sb.AppendLine("        .dialogue-text { color: #FFCC00; font-family: 'Segoe UI', sans-serif; font-size: 0.9em; margin-top: 10px; }");

            // Lapozó (Pagination) vezérlők stílusa
            sb.AppendLine("        .pagination { display: flex; justify-content: center; align-items: center; gap: 15px; margin: 30px 0; }");
            sb.AppendLine("        .pagination button { background: #007ACC; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold; }");
            sb.AppendLine("        .pagination button:disabled { background: #555; cursor: not-allowed; }");
            sb.AppendLine("        .pagination button:hover:not(:disabled) { background: #0099ff; }");
            sb.AppendLine("    </style>");
            sb.AppendLine("</head>");
            sb.AppendLine("<body>");
            sb.AppendLine("    <div class='container'>");
            sb.AppendLine($"        <h1>Bethesda Archaeological Laboratory – Analysis Report</h1>");
            sb.AppendLine($"        <div class='meta'>Target file: <strong>{pluginName}</strong> | Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss} | Total Findings: {findings.Count()}</div>");

            if (!findings.Any())
            {
                sb.AppendLine("        <div style='text-align:center; padding: 50px; color: #007ACC;'><h2>✓ Excellent result! No restorable or cut (Cut Content) records found in the file.</h2></div>");
            }
            else
            {
                // Lapozó gombok (Fent)
                sb.AppendLine("        <div class='pagination'><button id='btnPrevTop' onclick='prevPage()'>&laquo; Previous</button><span id='pageInfoTop'></span><button id='btnNextTop' onclick='nextPage()'>Next &raquo;</button></div>");

                // Ide generálja be a JavaScript a HTML-t
                sb.AppendLine("        <div id='resultsContainer'></div>");

                // Lapozó gombok (Lent)
                sb.AppendLine("        <div class='pagination'><button id='btnPrev' onclick='prevPage()'>&laquo; Previous</button><span id='pageInfo'></span><button id='btnNext' onclick='nextPage()'>Next &raquo;</button></div>");
            }

            sb.AppendLine("    </div>");

            // 1. LÉPÉS: Adatok kinyerése és JSON formátumra alakítása
            var exportData = findings.Select(f => {
                string cardClass = "high";
                string badgeClass = "high-tag";
                string badgeText = "HIGH SUSPECT";

                if (f.Category.Contains("Deleted")) { cardClass = "deleted"; badgeClass = "deleted-tag"; badgeText = "DELETED"; }
                else if (f.Category.Contains("Residual")) { cardClass = "residual"; badgeClass = "residual-tag"; badgeText = "RESIDUAL"; }

                var record = f.TargetRecord;
                var typeDetails = (record != null) ? GetRecordTypeDetails(record.Signature) : ("b-generic", "Other Record");

                return new
                {
                    Title = f.Title,
                    Category = f.Category,
                    Confidence = (f.Confidence * 100).ToString("F1"),
                    Description = StripTags(f.Description).Replace("\n", "<br>"),
                    CardClass = cardClass,
                    BadgeClass = badgeClass,
                    BadgeText = badgeText,

                    HasRecord = record != null,
                    Signature = record?.Signature,
                    FormId = record != null ? $"0x{record.FormId.Value:X8}" : "",
                    EditorId = string.IsNullOrEmpty(record?.EditorId) ? "<em>[None]</em>" : record.EditorId,
                    TypeBadgeClass = typeDetails.Item1,
                    TypeFriendlyName = typeDetails.Item2,

                    Weight = record?.Weight.ToString("F1") ?? "0.0",
                    Value = record?.Value.ToString() ?? "0",
                    Damage = record?.Damage?.ToString(),
                    AmmoId = record?.AmmoId,
                    EnchantmentId = record?.EnchantmentId,
                    CleanName = string.IsNullOrEmpty(record?.FullName) ? null : StripTags(record.FullName),

                    RelNpc = f.RelatedNpcCount,
                    RelDial = f.RelatedDialogueCount,
                    RelScene = f.RelatedSceneCount
                };
            });

            // Adatok beágyazása JavaScript változóként (JSON formátumban)
            string jsonData = JsonSerializer.Serialize(exportData);

            sb.AppendLine("    <script>");
            sb.AppendLine($"        const reportData = {jsonData};");
            sb.AppendLine(@"
        const itemsPerPage = 50; // ITT ÁLLÍTHATOD, HÁNY ELEM JELENJEN MEG EGY OLDALON
        let currentPage = 1;

        function renderPage(page) {
            const start = (page - 1) * itemsPerPage;
            const end = start + itemsPerPage;
            const itemsToRender = reportData.slice(start, end);
            const container = document.getElementById('resultsContainer');
            
            let html = '';
            itemsToRender.forEach(item => {
                html += `<div class='card ${item.CardClass}'>`;
                html += `    <div class='card-title'><span class='badge ${item.BadgeClass}'>${item.BadgeText}</span> ${item.Title}</div>`;
                html += `    <div class='card-meta'>Category: <strong>${item.Category}</strong> | Reliability: ${item.Confidence}%</div>`;
                
                if (item.HasRecord) {
                    html += `    <div class='evidence'>`;
                    html += `        <span class='badge-type ${item.TypeBadgeClass}'>${item.TypeFriendlyName} (${item.Signature})</span><br>`;
                    html += `        <strong>FormID:</strong> ${item.FormId}<br>`;
                    html += `        <strong>EditorID:</strong> ${item.EditorId}<br>`;
                    
                    if (item.Description) {
                        html += `        <div class='dev-note'>Developer Intent: <span style='color: #E0E0E0; font-family: Consolas, monospace; font-weight: normal;'>${item.Description}</span></div>`;
                    }
                    
                    html += `        <div class='stat-basic'>Weight: ${item.Weight} | Value: ${item.Value}</div>`;
                    
                    if (item.Damage) html += `        <div class='stat-damage'>Damage: ${item.Damage}</div>`;
                    if (item.AmmoId) html += `        <div class='stat-ammo'>Ammunition: ${item.AmmoId}</div>`;
                    if (item.EnchantmentId) html += `        <div class='stat-enchant'>Extra effect / Spell: ${item.EnchantmentId}</div>`;
                    if (item.CleanName) html += `        <div class='dialogue-text'><strong>Name / Dialogue:</strong> ${item.CleanName}</div>`;
                    
                    if (item.RelNpc > 0 || item.RelDial > 0 || item.RelScene > 0) {
                        let rels = [];
                        if (item.RelNpc > 0) rels.push(`${item.RelNpc} NPC`);
                        if (item.RelDial > 0) rels.push(`${item.RelDial} Dialógus`);
                        if (item.RelScene > 0) rels.push(`${item.RelScene} Jelenet`);
                        html += `        <div style='margin-top: 10px;'><strong style='color: #007ACC;'>Related hierarchy:</strong> ${rels.join(', ')}</div>`;
                    }
                    html += `    </div>`;
                }
                html += `</div>`;
            });
            
            container.innerHTML = html;
            
            // Gombok frissítése
            const totalPages = Math.ceil(reportData.length / itemsPerPage) || 1;
            const pageText = `Page ${currentPage} of ${totalPages}`;
            
            document.getElementById('pageInfo').innerText = pageText;
            if(document.getElementById('pageInfoTop')) document.getElementById('pageInfoTop').innerText = pageText;
            
            document.getElementById('btnPrev').disabled = currentPage === 1;
            document.getElementById('btnNext').disabled = currentPage === totalPages;
            if(document.getElementById('btnPrevTop')) document.getElementById('btnPrevTop').disabled = currentPage === 1;
            if(document.getElementById('btnNextTop')) document.getElementById('btnNextTop').disabled = currentPage === totalPages;
            
            window.scrollTo(0, 0); // Visszagörgetés a tetejére lapozás után
        }

        function nextPage() {
            const totalPages = Math.ceil(reportData.length / itemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                renderPage(currentPage);
            }
        }

        function prevPage() {
            if (currentPage > 1) {
                currentPage--;
                renderPage(currentPage);
            }
        }

        // Első oldal kirajzolása indításkor
        if (reportData.length > 0) {
            renderPage(1);
        }
            ");
            sb.AppendLine("    </script>");
            sb.AppendLine("</body>");
            sb.AppendLine("</html>");

            return sb.ToString();
        }

        private static string StripTags(string input)
        {
            if (string.IsNullOrEmpty(input)) return string.Empty;
            return Regex.Replace(input, "<.*?>", string.Empty, RegexOptions.Singleline);
        }

        private static (string BadgeClass, string FriendlyName) GetRecordTypeDetails(string signature)
        {
            return signature switch
            {
                "WEAP" => ("b-weap", "Weapon"),
                "ARMO" => ("b-armo", "Armor / Clothing"),
                "NPC_" => ("b-npc", "Character (NPC)"),
                "CELL" => ("b-cell", "Cell / Location"),
                "DIAL" => ("b-dial", "Dialogue Topic"),
                "INFO" => ("b-dial", "Dialogue Text"),
                _ => ("b-generic", "Other Record")
            };
        }
    }
}